package Vista;

import Modelo.*;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;

public class Juego extends javax.swing.JFrame {
    private DataInputStream in;
    private DataOutputStream out;
    private Proxy proxy = new Proxy();
    private String nickname;
    private List<String> apariencias;
    private List<int[]> matricesDanno;

    public void colocarVidas(int index) {
        lblMatriz1.setText(Arrays.toString(matricesDanno.get(index)));
        lblMatriz2.setText(Arrays.toString(matricesDanno.get(++index)));
        lblMatriz3.setText(Arrays.toString(matricesDanno.get(++index)));
        lblMatriz4.setText(Arrays.toString(matricesDanno.get(++index)));
        lblMatriz5.setText(Arrays.toString(matricesDanno.get(++index)));
    }

    public void colocarMatrices() {
        int index = matricesDanno.size() - 1;
        lblMatriz1.setText(Arrays.toString(matricesDanno.get(index)));
        lblMatriz2.setText(Arrays.toString(matricesDanno.get(--index)));
        lblMatriz3.setText(Arrays.toString(matricesDanno.get(--index)));
        lblMatriz4.setText(Arrays.toString(matricesDanno.get(--index)));
        lblMatriz5.setText(Arrays.toString(matricesDanno.get(--index)));
    }

    public Juego(DataInputStream in, DataOutputStream out) {
        initComponents();
        // Se asigna el in y el out.
        this.in = in;
        this.out = out;
        this.apariencias = new ArrayList<>();
        this.matricesDanno = new ArrayList<>();
        setResizable(false);
        setTitle("Partida");
        getContentPane().setBackground(Color.BLACK);
        this.setLocationRelativeTo(null);
        textAreaRespuestas.setText("------------- Mortal Kombat ------------- ");

    }

    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // <editor-fold defaultstate="collapsed" desc="Generated
    // Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        panel = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        lblMensajeRecibido2 = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        textAreaRanking = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        textAreaAgainst = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        textAreaRespuestas = new javax.swing.JTextArea();
        lineaComandos = new javax.swing.JTextField();
        lblArmaUsada = new javax.swing.JLabel();
        lblDannoRealizado = new javax.swing.JLabel();
        lblMensajeRecibido = new javax.swing.JLabel();
        lblAtaqueEnemigo = new javax.swing.JLabel();
        lblAtaqueEnviado = new javax.swing.JLabel();
        lblYourTeam = new javax.swing.JLabel();
        lblVida1 = new javax.swing.JLabel();
        lblVida2 = new javax.swing.JLabel();
        lblVida3 = new javax.swing.JLabel();
        lblVida4 = new javax.swing.JLabel();
        lblNombre1 = new javax.swing.JLabel();
        lblNombre2 = new javax.swing.JLabel();
        lblNombre3 = new javax.swing.JLabel();
        lblNombre4 = new javax.swing.JLabel();
        lblPersonaje1 = new javax.swing.JLabel();
        lblPersonaje2 = new javax.swing.JLabel();
        lblPersonaje3 = new javax.swing.JLabel();
        lblPersonaje4 = new javax.swing.JLabel();
        lblArma1 = new javax.swing.JLabel();
        lblArma2 = new javax.swing.JLabel();
        lblArma3 = new javax.swing.JLabel();
        lblArma4 = new javax.swing.JLabel();
        lblArma5 = new javax.swing.JLabel();
        lblMatriz1 = new javax.swing.JLabel();
        lblMatriz2 = new javax.swing.JLabel();
        lblMatriz3 = new javax.swing.JLabel();
        lblMatriz4 = new javax.swing.JLabel();
        lblMatriz5 = new javax.swing.JLabel();
        lblArmasPersonaje = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        textAreaMyStatus = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panel.setBackground(new java.awt.Color(0, 0, 0));
        panel.setForeground(new java.awt.Color(204, 0, 0));
        panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblMensajeRecibido2.setColumns(20);
        lblMensajeRecibido2.setRows(5);
        jScrollPane6.setViewportView(lblMensajeRecibido2);

        panel.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 30, 370, 190));

        textAreaRanking.setBackground(new java.awt.Color(0, 0, 0));
        textAreaRanking.setColumns(20);
        textAreaRanking.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        textAreaRanking.setForeground(new java.awt.Color(0, 204, 0));
        textAreaRanking.setRows(5);
        jScrollPane1.setViewportView(textAreaRanking);

        panel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, 300, 217));

        textAreaAgainst.setBackground(new java.awt.Color(0, 0, 0));
        textAreaAgainst.setColumns(20);
        textAreaAgainst.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        textAreaAgainst.setForeground(new java.awt.Color(0, 204, 0));
        textAreaAgainst.setRows(5);
        jScrollPane3.setViewportView(textAreaAgainst);

        panel.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 235, 300, 150));

        textAreaRespuestas.setBackground(new java.awt.Color(0, 0, 0));
        textAreaRespuestas.setColumns(20);
        textAreaRespuestas.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        textAreaRespuestas.setForeground(new java.awt.Color(0, 204, 0));
        textAreaRespuestas.setRows(5);
        jScrollPane4.setViewportView(textAreaRespuestas);

        panel.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 553, 1516, -1));

        lineaComandos.setBackground(new java.awt.Color(0, 0, 0));
        lineaComandos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lineaComandos.setForeground(new java.awt.Color(0, 204, 0));
        lineaComandos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                lineaComandosKeyReleased(evt);
            }
        });
        panel.add(lineaComandos, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 665, 1516, -1));

        lblArmaUsada.setBackground(new java.awt.Color(0, 0, 0));
        lblArmaUsada.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblArmaUsada.setForeground(new java.awt.Color(255, 255, 255));
        panel.add(lblArmaUsada, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 340, 350, 20));

        lblDannoRealizado.setBackground(new java.awt.Color(0, 0, 0));
        lblDannoRealizado.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblDannoRealizado.setForeground(new java.awt.Color(255, 255, 255));
        panel.add(lblDannoRealizado, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 400, 360, 80));

        lblMensajeRecibido.setBackground(new java.awt.Color(0, 0, 0));
        lblMensajeRecibido.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblMensajeRecibido.setForeground(new java.awt.Color(255, 255, 255));
        panel.add(lblMensajeRecibido, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 350, 50));

        lblAtaqueEnemigo.setBackground(new java.awt.Color(102, 102, 102));
        lblAtaqueEnemigo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/mkicon.jpg"))); // NOI18N
        lblAtaqueEnemigo.setText("hola");
        lblAtaqueEnemigo.setOpaque(true);
        panel.add(lblAtaqueEnemigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(324, 6, 381, -1));

        lblAtaqueEnviado.setBackground(new java.awt.Color(102, 102, 102));
        lblAtaqueEnviado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/mkicon.jpg"))); // NOI18N
        lblAtaqueEnviado.setOpaque(true);
        panel.add(lblAtaqueEnviado, new org.netbeans.lib.awtextra.AbsoluteConstraints(324, 281, 381, 266));

        lblYourTeam.setBackground(new java.awt.Color(0, 0, 0));
        lblYourTeam.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblYourTeam.setForeground(new java.awt.Color(255, 255, 255));
        lblYourTeam.setText("Your team");
        lblYourTeam.setOpaque(true);
        panel.add(lblYourTeam, new org.netbeans.lib.awtextra.AbsoluteConstraints(717, 6, -1, 26));

        lblVida1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblVida1.setForeground(new java.awt.Color(255, 255, 255));
        lblVida1.setText("100%");
        panel.add(lblVida1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 310, -1, -1));

        lblVida2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblVida2.setForeground(new java.awt.Color(255, 255, 255));
        lblVida2.setText("100%");
        panel.add(lblVida2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 310, -1, -1));

        lblVida3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblVida3.setForeground(new java.awt.Color(255, 255, 255));
        lblVida3.setText("100%");
        panel.add(lblVida3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 310, -1, -1));

        lblVida4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblVida4.setForeground(new java.awt.Color(255, 255, 255));
        lblVida4.setText("100%");
        panel.add(lblVida4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1410, 310, -1, -1));

        lblNombre1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNombre1.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre1.setText("Nombre");
        panel.add(lblNombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 40, -1, -1));

        lblNombre2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNombre2.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre2.setText("Nombre");
        panel.add(lblNombre2, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 40, -1, -1));

        lblNombre3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNombre3.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre3.setText("Nombre");
        panel.add(lblNombre3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 40, -1, -1));

        lblNombre4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNombre4.setForeground(new java.awt.Color(255, 255, 255));
        lblNombre4.setText("Nombre");
        panel.add(lblNombre4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1390, 40, -1, -1));

        lblPersonaje1.setBackground(new java.awt.Color(102, 102, 102));
        lblPersonaje1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPersonaje1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nodisponible.jpg"))); // NOI18N
        lblPersonaje1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPersonaje1MouseEntered(evt);
            }
        });
        panel.add(lblPersonaje1, new org.netbeans.lib.awtextra.AbsoluteConstraints(717, 37, -1, 303));

        lblPersonaje2.setBackground(new java.awt.Color(102, 102, 102));
        lblPersonaje2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nodisponible.jpg"))); // NOI18N
        lblPersonaje2.setOpaque(true);
        lblPersonaje2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPersonaje2MouseEntered(evt);
            }
        });
        panel.add(lblPersonaje2, new org.netbeans.lib.awtextra.AbsoluteConstraints(923, 37, 201, 303));

        lblPersonaje3.setBackground(new java.awt.Color(102, 102, 102));
        lblPersonaje3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nodisponible.jpg"))); // NOI18N
        lblPersonaje3.setOpaque(true);
        lblPersonaje3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPersonaje3MouseEntered(evt);
            }
        });
        panel.add(lblPersonaje3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 37, 199, 303));

        lblPersonaje4.setBackground(new java.awt.Color(102, 102, 102));
        lblPersonaje4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/nodisponible.jpg"))); // NOI18N
        lblPersonaje4.setOpaque(true);
        lblPersonaje4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblPersonaje4MouseEntered(evt);
            }
        });
        panel.add(lblPersonaje4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1335, 37, 190, 303));

        lblArma1.setBackground(new java.awt.Color(0, 0, 0));
        lblArma1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArma1.setForeground(new java.awt.Color(255, 255, 255));
        lblArma1.setText("Arma 1");
        lblArma1.setOpaque(true);
        panel.add(lblArma1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 390, 77, -1));

        lblArma2.setBackground(new java.awt.Color(0, 0, 0));
        lblArma2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArma2.setForeground(new java.awt.Color(255, 255, 255));
        lblArma2.setText("Arma 2");
        lblArma2.setOpaque(true);
        panel.add(lblArma2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 420, 77, -1));

        lblArma3.setBackground(new java.awt.Color(0, 0, 0));
        lblArma3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArma3.setForeground(new java.awt.Color(255, 255, 255));
        lblArma3.setText("Arma 3");
        lblArma3.setOpaque(true);
        panel.add(lblArma3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 450, 77, -1));

        lblArma4.setBackground(new java.awt.Color(0, 0, 0));
        lblArma4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArma4.setForeground(new java.awt.Color(255, 255, 255));
        lblArma4.setText("Arma 4");
        lblArma4.setOpaque(true);
        panel.add(lblArma4, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 480, 77, -1));

        lblArma5.setBackground(new java.awt.Color(0, 0, 0));
        lblArma5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArma5.setForeground(new java.awt.Color(255, 255, 255));
        lblArma5.setText("Arma 5");
        lblArma5.setOpaque(true);
        panel.add(lblArma5, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 510, 77, -1));

        lblMatriz1.setBackground(new java.awt.Color(0, 0, 0));
        lblMatriz1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMatriz1.setForeground(new java.awt.Color(255, 255, 255));
        lblMatriz1.setText("[80, 97, 100, 88, 20, 33, 74, 98, 80, 30]");
        lblMatriz1.setOpaque(true);
        panel.add(lblMatriz1, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 390, 510, -1));

        lblMatriz2.setBackground(new java.awt.Color(0, 0, 0));
        lblMatriz2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMatriz2.setForeground(new java.awt.Color(255, 255, 255));
        lblMatriz2.setText("[80, 97, 100, 88, 20, 33, 74, 98, 80, 30]");
        lblMatriz2.setOpaque(true);
        panel.add(lblMatriz2, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 420, 510, -1));

        lblMatriz3.setBackground(new java.awt.Color(0, 0, 0));
        lblMatriz3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMatriz3.setForeground(new java.awt.Color(255, 255, 255));
        lblMatriz3.setText("[80, 97, 100, 88, 20, 33, 74, 98, 80, 30]");
        lblMatriz3.setOpaque(true);
        panel.add(lblMatriz3, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 450, 510, -1));

        lblMatriz4.setBackground(new java.awt.Color(0, 0, 0));
        lblMatriz4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMatriz4.setForeground(new java.awt.Color(255, 255, 255));
        lblMatriz4.setText("[80, 97, 100, 88, 20, 33, 74, 98, 80, 30]");
        lblMatriz4.setOpaque(true);
        panel.add(lblMatriz4, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 480, 510, -1));

        lblMatriz5.setBackground(new java.awt.Color(0, 0, 0));
        lblMatriz5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblMatriz5.setForeground(new java.awt.Color(255, 255, 255));
        lblMatriz5.setText("[80, 97, 100, 88, 20, 33, 74, 98, 80, 30]");
        lblMatriz5.setOpaque(true);
        panel.add(lblMatriz5, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 510, 510, -1));

        lblArmasPersonaje.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblArmasPersonaje.setForeground(new java.awt.Color(255, 255, 255));
        lblArmasPersonaje.setText("Armas");
        panel.add(lblArmasPersonaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 352, 220, 40));

        textAreaMyStatus.setBackground(new java.awt.Color(0, 0, 0));
        textAreaMyStatus.setColumns(20);
        textAreaMyStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        textAreaMyStatus.setForeground(new java.awt.Color(0, 204, 0));
        textAreaMyStatus.setRows(5);
        jScrollPane5.setViewportView(textAreaMyStatus);

        panel.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 397, 300, 150));

        jScrollPane2.setViewportView(jEditorPane1);

        panel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE,
                                        javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE,
                                Short.MAX_VALUE));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblPersonaje1MouseEntered(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_lblPersonaje1MouseEntered
        if (matricesDanno.size() >= 5)
            colocarVidas(0);
    }// GEN-LAST:event_lblPersonaje1MouseEntered

    private void lblPersonaje2MouseEntered(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_lblPersonaje2MouseEntered
        if (matricesDanno.size() >= 10)
            colocarVidas(5);
    }// GEN-LAST:event_lblPersonaje2MouseEntered

    private void lblPersonaje3MouseEntered(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_lblPersonaje3MouseEntered
        if (matricesDanno.size() >= 15)
            colocarVidas(10);
    }// GEN-LAST:event_lblPersonaje3MouseEntered

    private void lblPersonaje4MouseEntered(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_lblPersonaje4MouseEntered
        if (matricesDanno.size() >= 20)
            colocarVidas(15);
    }// GEN-LAST:event_lblPersonaje4MouseEntered

    public void comandoLoguerse(String[] ary) {
        if (ary.length == 2) {
            try {
                out.writeInt(1);
                out.writeUTF(ary[0]);
                out.writeUTF(ary[1]);
                if (in.readBoolean()) {
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nTe uniste a la partida " + ary[1]);
                    this.nickname = ary[1];
                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + "Te uniste a la partida", ary[1]);
                } else {
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nExistió un error al loguearse");
                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + "Existió un error al loguearse",
                            ary[1]);
                }
            } catch (IOException ex) {
                Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            textAreaRespuestas.setText(textAreaRespuestas.getText() +
                    "\nLa longitud del comando debe ser de 2");
            proxy.insertar(ary[0] + "-" + ary[1] + "-" + "La longitud del comando debe ser de 2", ary[1]);
        }
    }

    public void colocarImagenes() {
        int index = this.apariencias.size();
        switch (index) {
            case 1 -> lblPersonaje1.setIcon(new ImageIcon(System.getProperty("user.dir") +
                    this.apariencias.get(index - 1)));
            case 2 -> lblPersonaje2.setIcon(new ImageIcon(System.getProperty("user.dir") +
                    this.apariencias.get(index - 1)));
            case 3 -> lblPersonaje3.setIcon(new ImageIcon(System.getProperty("user.dir") +
                    this.apariencias.get(index - 1)));
            case 4 -> lblPersonaje4.setIcon(new ImageIcon(System.getProperty("user.dir") +
                    this.apariencias.get(index - 1)));
            default -> throw new AssertionError();
        }
    }

    public int[] convertToIntArray(String str) {
        String[] splitArray = str.split(", ");
        int[] array = new int[splitArray.length];
        for (int i = 0; i < splitArray.length; i++) {
            array[i] = Integer.parseInt(splitArray[i]);
        }
        return array;
    }

    public void addToIntegerArray(String arr) {
        arr = arr.replaceAll("[\\[\\]]", "");
        this.matricesDanno.add(convertToIntArray(arr));
    }

    public void colocarNombre(String nombre) {
        int index = apariencias.size() - 1;
        switch (index) {
            case 0:
                lblNombre1.setText(nombre);
                break;
            case 1:
                lblNombre2.setText(nombre);
                break;
            case 2:
                lblNombre3.setText(nombre);
                break;
            case 3:
                lblNombre4.setText(nombre);
                break;
            default:
                break;
        }

    }

    public void comandoElegirPersonaje(String[] ary) {
        if (ary.length == 7) {
            try {
                out.writeInt(2);
                boolean EsTurno = in.readBoolean();
                if (EsTurno == true) {
                    out.writeUTF(ary[0]);
                    out.writeUTF(ary[1]);
                    out.writeUTF(ary[2]);
                    out.writeUTF(ary[3]);
                    out.writeUTF(ary[4]);
                    out.writeUTF(ary[5]);
                    out.writeUTF(ary[6]);
                    if (in.readBoolean()) {
                        this.apariencias.add(in.readUTF());
                        colocarImagenes();
                        textAreaRespuestas.setText(textAreaRespuestas.getText() +
                                "\nPersonaje agregado correctamente");
                        addToIntegerArray(in.readUTF());
                        addToIntegerArray(in.readUTF());
                        addToIntegerArray(in.readUTF());
                        addToIntegerArray(in.readUTF());
                        addToIntegerArray(in.readUTF());
                        colocarMatrices();
                        colocarNombre(ary[1]);
                        proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-"
                                + ary[4] + "-" + ary[5]
                                + "-" + ary[6] + "- "
                                + "Personaje agregado correctamente", this.nickname);
                    } else {
                        textAreaRespuestas.setText(textAreaRespuestas.getText() +
                                "\nExistió un error al elegir al personaje");

                        proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-"
                                + ary[4] + "-" + ary[5]
                                + "-" + ary[6] + "- "
                                + "Existe un error al elegir al personaje",
                                this.nickname);
                    }
                } else {
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nNo es tu turno...");

                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-"
                            + ary[4] + "-" + ary[5]
                            + "-" + ary[6] + "- " + "No es tu turno...", this.nickname);
                }
            } catch (IOException ex) {
                Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else

        {
            textAreaRespuestas.setText(textAreaRespuestas.getText() +
                    "\nLa longitud del comando debe ser de 7");

            proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-" + ary[4] + "-" + ary[5]
                    + "-" + ary[6] + "- " + "La longitud del comando debe ser de 7", this.nickname);
        }
    }

    public void comandoAtacar(String[] ary) {
        if (ary.length == 4) {
            try {
                out.writeInt(3);
                out.writeUTF(ary[0]);
                out.writeUTF(ary[1]);
                out.writeUTF(ary[2]);
                out.writeUTF(ary[3]);
                boolean EsTurno = in.readBoolean();
                if (in.readBoolean() && EsTurno) {
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nSe realizó el ataque correctamente");
                    String tipoPersonaje = in.readUTF();
                    lblMensajeRecibido.setText("Atacaste a " + ary[1] + " con " + ary[2] + " [" + tipoPersonaje + "]");
                    lblArmaUsada.setText("Arma: " + ary[3]);
                    int vida1 = in.readInt();
                    int vida2 = in.readInt();
                    int vida3 = in.readInt();
                    int vida4 = in.readInt();
                    lblVida1.setText(Integer.toString(vida1));
                    lblVida2.setText(Integer.toString(vida2));
                    lblVida3.setText(Integer.toString(vida3));
                    lblVida4.setText(Integer.toString(vida4));
                    lblDannoRealizado.setText("-" + in.readUTF());
                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "- "
                            + "Se realizó el ataque correctamente", this.nickname);
                } else {
                    // in.readBoolean();
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nExistió un error al atacar");

                    proxy.insertar(
                            ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "- "
                                    + "Existió un error al atacar",
                            this.nickname);
                }
            } catch (IOException ex) {
                Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
            }
        } // SI ES 7 TIENE QUE APLICAR EL COMODIN
        else if (ary.length == 7 && "COMODIN".equals(ary[1])) {
            try {
                out.writeInt(4);
                out.writeUTF(ary[0]);
                out.writeUTF(ary[1]);
                out.writeUTF(ary[2]);
                out.writeUTF(ary[3]);
                out.writeUTF(ary[4]);
                out.writeUTF(ary[5]);
                out.writeUTF(ary[6]);
                boolean EsTurno = in.readBoolean();
                if (in.readBoolean() && EsTurno) {
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nSe realizó el ataque con COMODIN correctamente");
                    String tipoPersonaje = in.readUTF();
                    String tipoPersonaje2 = in.readUTF();
                    lblMensajeRecibido.setText(
                            "Atacaste a " + ary[1] + " con " + ary[3] + " [" + tipoPersonaje + "]"
                                    + "," + ary[5] + " [" + tipoPersonaje2 + "]");
                    lblArmaUsada.setText("Armas: " + ary[4] + ", " + ary[6]);
                    int vida1 = in.readInt();
                    int vida2 = in.readInt();
                    int vida3 = in.readInt();
                    int vida4 = in.readInt();
                    lblVida1.setText(Integer.toString(vida1));
                    lblVida2.setText(Integer.toString(vida2));
                    lblVida3.setText(Integer.toString(vida3));
                    lblVida4.setText(Integer.toString(vida4));
                    lblDannoRealizado.setText("-" + in.readUTF());
                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-"
                            + ary[4] + "-" + ary[5]
                            + "-" + ary[6] + "- "
                            + "Se realizó el ataque con COMODIN correctamente",
                            this.nickname);

                } else {
                    // in.readBoolean();
                    textAreaRespuestas.setText(textAreaRespuestas.getText() +
                            "\nExistió un error al atacar con COMODIN");

                    proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-" + ary[3] + "-"
                            + ary[4] + "-" + ary[5]
                            + "-" + ary[6] + "- "
                            + "Existió un error al atacar con COMODIN", this.nickname);

                }

            } catch (IOException ex) {
                Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void comandoChatPublico(String[] ary) {
        try {
            out.writeInt(5);
            out.writeUTF(ary[0]);
            out.writeUTF(ary[1]);
            boolean EsTurno = in.readBoolean();
            if (in.readBoolean() && EsTurno) {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nSe mando el mensaje a todos los jugadores");

                proxy.insertar(ary[0] + "-" + ary[1] + "- "
                        + "Se mando el mensaje a todos los jugadores",
                        this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nExistió un error al mandar el mensaje");

                proxy.insertar(ary[0] + "-" + ary[1] + "- "
                        + "Existió un error al mandar el mensaje",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoVerMensajes(String[] ary) {
        try {
            out.writeInt(7);
            String mensaje = in.readUTF();
            textAreaRespuestas.setText(textAreaRespuestas.getText() +
                    "\n" + mensaje);

            proxy.insertar(ary[0] + "-" + "No hubieron parámetros " + "-" + mensaje,
                    this.nickname);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void comandoChatPrivado(String[] ary) {
        try {
            out.writeInt(6);
            out.writeUTF(ary[0]);
            out.writeUTF(ary[1]);
            out.writeUTF(ary[2]);
            boolean EsTurno = in.readBoolean();
            if (in.readBoolean() && EsTurno) {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nSe mando el mensaje al jugador " + ary[1]);

                proxy.insertar(ary[0] + "-" + ary[1] + "-" + ary[2] + "-"
                        + " Se mando el mensaje al jugador",
                        this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nExistió un error al mandar el mensaje");
                proxy.insertar(
                        ary[0] + "-" + ary[1] + "-" + ary[2] + "-"
                                + "Existió un error al mandar el mensaje",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoRecargar(String[] ary) {
        try {
            out.writeInt(8);
            out.writeUTF(ary[0]);
            if (in.readBoolean()) {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nSe recargaron las armas");

                proxy.insertar(ary[0] + "-" + " Se recargaron las armas", this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nNo se pudieron recargar las armas");

                proxy.insertar(ary[0] + "-" + " No se pudieron recargar las armas", this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoSalida(String[] ary) {
        try {
            out.writeInt(9);
            out.writeUTF(ary[0]);
            boolean esTurno = in.readBoolean();
            if (in.readBoolean() && esTurno) {
                String nickname = in.readUTF();
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nEl jugador " + nickname + " ha aprobado la salida mutua");

                proxy.insertar(ary[0] + "-" + "El jugador " + nickname + " ha aprobado la salida mutua",
                        this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nNo se pudo hacer la solicitud de salida mutua");

                proxy.insertar(ary[0] + "-" + "No se pudo hacer la solicitud de salida mutua",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoRendirse(String[] ary) {
        try {
            out.writeInt(10);
            out.writeUTF(ary[0]);
            boolean esTurno = in.readBoolean();
            if (in.readBoolean() && esTurno) {
                String nombre = in.readUTF();
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nEl jugador " + nombre + " se ha rendido");

                proxy.insertar(ary[0] + "-" + "El jugador " + nombre + " se ha rendido",
                        this.nickname);

            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nNo se pudo hacer la rendicion del jugador");

                proxy.insertar(ary[0] + "-" + "No se pudo hacer la rendicion del jugador",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoTurno(String[] ary) {
        try {
            out.writeInt(11);
            out.writeUTF(ary[0]);
            boolean esTurno = in.readBoolean();
            if (in.readBoolean() && esTurno) {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nEl jugador ha pasado el turno");

                proxy.insertar(ary[0] + "-" + " El jugador ha pasado el turno",
                        this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nNo se pudo pasar el turno del jugador");

                proxy.insertar(ary[0] + "-" + " No se pudo pasar el turno del jugador",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoVerArchivo(String[] ary) {
        try {
            out.writeInt(12);
            out.writeUTF(ary[0]);
            boolean respuesta = in.readBoolean();
            if (respuesta) {
                String mensajes = in.readUTF();
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\n" + mensajes);

                proxy.insertar(ary[0] + "-" + mensajes,
                        this.nickname);
            } else {
                textAreaRespuestas.setText(textAreaRespuestas.getText() +
                        "\nNo se pudo hacer el comando ver archivo");

                proxy.insertar(ary[0] + "-" + " No se pudo hacer el comando ver archivo",
                        this.nickname);
            }
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoSelect(String[] ary) {
        try {
            out.writeInt(13);
            out.writeUTF(ary[0]);
            out.writeUTF(ary[1]);
            boolean respuesta = in.readBoolean();
            String mensaje = in.readUTF();
            textAreaAgainst.setText(mensaje);

            proxy.insertar(ary[0] + "-" + ary[1] + "-" + mensaje,
                    this.nickname);

        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoMyStatus(String[] ary) {
        try {
            out.writeInt(14);
            out.writeUTF(ary[0]);
            boolean respuesta = in.readBoolean();
            String mensaje = in.readUTF();
            textAreaMyStatus.setText(mensaje);
            proxy.insertar(ary[0] + "-" + mensaje,
                    this.nickname);
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoRanking(String[] ary) {
        try {
            out.writeInt(15);
            out.writeUTF(ary[0]);
            boolean respuesta = in.readBoolean();
            String mensaje = in.readUTF();
            textAreaRanking.setText(mensaje);
            proxy.insertar(ary[0] + "-" + mensaje,
                    this.nickname);
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void comandoVerUltimo(String[] ary) {
        try {
            out.writeInt(16);
            out.writeUTF(ary[0]);
            String mensaje = in.readUTF();
            lblMensajeRecibido2.setText(mensaje);
            System.out.println(mensaje);
            proxy.insertar(ary[0] + "-" + mensaje,
                    this.nickname);
        } catch (IOException ex) {
            Logger.getLogger(Juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void lineaComandosKeyReleased(java.awt.event.KeyEvent evt) {// GEN-FIRST:event_lineaComandosKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            String[] ary = lineaComandos.getText().split(" -");
            switch (ary[0]) {
                case "LOGUEARSE" -> comandoLoguerse(ary);
                case "ELEGIRPERSONAJE" -> comandoElegirPersonaje(ary);
                case "ATTACK" -> comandoAtacar(ary);
                case "CHATPUBLICO" -> comandoChatPublico(ary);
                case "CHATPRIVADO" -> comandoChatPrivado(ary);
                case "RECARGAR" -> comandoRecargar(ary);
                case "SALIDAMUTUA" -> comandoSalida(ary);
                case "RENDIRSE" -> comandoRendirse(ary);
                case "PASARTURNO" -> comandoTurno(ary);
                case "SELECT" -> comandoSelect(ary);
                case "VERARCHIVO" -> comandoVerArchivo(ary);
                case "VERMENSAJES" -> comandoVerMensajes(ary);
                case "MYSTATUS" -> comandoMyStatus(ary);
                case "RANKING" -> comandoRanking(ary);
                case "VERULTIMOATAQUE" -> comandoVerUltimo(ary);
                default -> {
                }
            }
        }
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager
                    .getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException
                | InstantiationException
                | IllegalAccessException
                | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Juego.class.getName())
                    .log(java.util.logging.Level.SEVERE,
                            null, ex);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lblArma1;
    private javax.swing.JLabel lblArma2;
    private javax.swing.JLabel lblArma3;
    private javax.swing.JLabel lblArma4;
    private javax.swing.JLabel lblArma5;
    private javax.swing.JLabel lblArmaUsada;
    private javax.swing.JLabel lblArmasPersonaje;
    private javax.swing.JLabel lblAtaqueEnemigo;
    private javax.swing.JLabel lblAtaqueEnviado;
    private javax.swing.JLabel lblDannoRealizado;
    private javax.swing.JLabel lblMatriz1;
    private javax.swing.JLabel lblMatriz2;
    private javax.swing.JLabel lblMatriz3;
    private javax.swing.JLabel lblMatriz4;
    private javax.swing.JLabel lblMatriz5;
    private javax.swing.JLabel lblMensajeRecibido;
    private javax.swing.JTextArea lblMensajeRecibido2;
    private javax.swing.JLabel lblNombre1;
    private javax.swing.JLabel lblNombre2;
    private javax.swing.JLabel lblNombre3;
    private javax.swing.JLabel lblNombre4;
    private javax.swing.JLabel lblPersonaje1;
    private javax.swing.JLabel lblPersonaje2;
    private javax.swing.JLabel lblPersonaje3;
    private javax.swing.JLabel lblPersonaje4;
    private javax.swing.JLabel lblVida1;
    private javax.swing.JLabel lblVida2;
    private javax.swing.JLabel lblVida3;
    private javax.swing.JLabel lblVida4;
    private javax.swing.JLabel lblYourTeam;
    private javax.swing.JTextField lineaComandos;
    private javax.swing.JPanel panel;
    private javax.swing.JTextArea textAreaAgainst;
    private javax.swing.JTextArea textAreaMyStatus;
    private javax.swing.JTextArea textAreaRanking;
    private javax.swing.JTextArea textAreaRespuestas;
    // End of variables declaration//GEN-END:variables
}
