
package Control;

import Modelo.Jugador;
import Modelo.ScoresXPartida;

import java.util.ArrayList;
import java.util.List;

public class AdmScoresXPartida {
    private static List<ScoresXPartida> scores = new ArrayList<>();

    public AdmScoresXPartida() {
    }

    public static ScoresXPartida existePartida(Jugador atacante, Jugador atacado) {
        int i = 0;
        String nombreAtacante = atacante.getNombre();
        String nombreAtacado = atacado.getNombre();
        while (i < scores.size()) {
            String atacanteTmp = scores.get(i).getAtacante().getNombre();
            if (atacanteTmp.equals(nombreAtacante)) {
                String atacanteTmp2 = scores.get(i).getAtacado().getNombre();
                if (atacanteTmp2.equals(nombreAtacado)) {
                    return scores.get(i);
                }
            }
            i++;
        }
        return null;
    }

    public static void agregarPartida(Jugador atacante, Jugador atacado) {
        ScoresXPartida nuevoScore = new ScoresXPartida(atacante, atacado);
        scores.add(nuevoScore);
    }

    public static void actualizarEstadisticas(ScoresXPartida scoreActualizado) {
        int i = 0;
        String nombreAtacante = scoreActualizado.getAtacante().getNombre();
        String nombreAtacado = scoreActualizado.getAtacado().getNombre();
        while (i < scores.size()) {
            String atacanteTmp = scores.get(i).getAtacante().getNombre();
            String atacanteTmp2 = scores.get(i).getAtacado().getNombre();
            if (atacanteTmp == nombreAtacante && atacanteTmp2 == nombreAtacado) {
                scores.set(i, scoreActualizado);
            }
            i++;
        }
    }

    public static List<ScoresXPartida> getScores() {
        return scores;
    }

    public static void setScores(List<ScoresXPartida> scores) {
        AdmScoresXPartida.scores = scores;
    }

}
