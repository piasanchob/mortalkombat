/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

import Modelo.Partida;
import java.util.HashMap;

/**
 *
 * @author gabri
 */
public class AdmPartidas {
    private static HashMap<Integer, Partida> partidas = new HashMap<>();

    public AdmPartidas() {
    }

    public static void agregarPartida(Partida partida) {
        if (partida != null && partidas.containsKey(partida.getId()) == false) {
            partidas.put(partida.getId(), partida);
        }
    }

    public static Partida consultarPartida(int id) {
        if (id > 0 && partidas.containsKey(id)) {
            return partidas.get(id);
        }
        return null;
    }

    public static HashMap<Integer, Partida> getPartidas() {
        return partidas;
    }

    public static void setPartidas(HashMap<Integer, Partida> partidas) {
        AdmPartidas.partidas = partidas;
    }

}
