package Control;

import java.util.HashMap;

import Modelo.Arma;
import Modelo.Jugador;
import Modelo.Personaje;

public class Juego {
    private String nombre;
    private HashMap<String, Jugador> jugadores;
    private HashMap<String, Arma> armas; // todas las armas del juego
    private HashMap<String, Personaje> personajes; // todos los personajes del juego

    public Juego(String nombre, HashMap<String, Jugador> jugadores,
            HashMap<String, Arma> armas,
            HashMap<String, Personaje> personajes) {
        this.nombre = nombre;
        this.jugadores = jugadores;
        this.armas = armas;
        this.personajes = personajes;
    }

    public Juego(String nombre) {
        this.nombre = nombre;
        this.jugadores = new HashMap<>();
        this.armas = new HashMap<>();
        this.personajes = new HashMap<>();
    }

    public HashMap<String, Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(HashMap<String, Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    public HashMap<String, Arma> getArmas() {
        return armas;
    }

    public void setArmas(HashMap<String, Arma> armas) {
        this.armas = armas;
    }

    public HashMap<String, Personaje> getPersonajes() {
        return personajes;
    }

    public void setPersonajes(HashMap<String, Personaje> personajes) {
        this.personajes = personajes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void agregarJugadores(Jugador jugador) {
        if (jugador != null) {
            jugadores.put(jugador.getNombre(), jugador);
        }
    }

    @Override
    public String toString() {
        return "Juego [nombre=" + nombre + ", jugadores=" +
                jugadores + ", armas=" + armas + ", personajes="
                + personajes + "]";
    }

}
