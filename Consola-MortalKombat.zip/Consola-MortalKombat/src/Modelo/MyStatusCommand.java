package Modelo;

import Control.AdmPartidas;

public class MyStatusCommand implements ICommand {
    public static final String COMMAND_NAME = "MYSTATUS";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean validarJugador(Jugador jugador) {
        String mensaje = "My Status: " +
                "\n Ganes: " + jugador.getscorePersonal().getGanes() +
                "\n Perdidas: " + jugador.getscorePersonal().getPerdidas() +
                "\n Ataques Exitosos: " + jugador.getscorePersonal().getAtaquesExitosos() +
                "\n Ataques Fracasados: " + jugador.getscorePersonal().getAtaquesFracasados() +
                "\n Ataques: "
                + (jugador.getscorePersonal().getAtaquesFracasados() + jugador.getscorePersonal().getAtaquesExitosos())
                +
                "\n Rendiciones: " + jugador.getscorePersonal().getRendiciones();
        AdmPartidas.getPartidas().get(1).buscarJugador(jugador.getNombre()).addMensajes(mensaje);
        return true;
    }

    @Override
    public boolean execute(String[] args, Jugador jugador) {
        boolean respuesta = validarJugador(jugador);
        return respuesta;
    }
}