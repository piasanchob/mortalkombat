package Modelo;

public interface iLogger {

    String insertar(String txt, String nombre);
   // int eliminar(int id);
   // int modificar(int id, String txt);
    
}
