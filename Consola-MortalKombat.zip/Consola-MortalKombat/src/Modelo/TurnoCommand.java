package Modelo;

import Control.AdmPartidas;

public class TurnoCommand implements ICommand {
    public static final String COMMAND_NAME = "PASARTURNO";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        int indexAtacante = AdmPartidas.getPartidas().get(1).getObservers().indexOf(atacante);
        if (indexAtacante + 1 >= AdmPartidas.getPartidas().get(1).getObservers().size()) {
            Jugador jugadorSiguiente = (Jugador) AdmPartidas.getPartidas().get(1).getObservers().get(0);
            jugadorSiguiente.setTurno(true);
            AdmPartidas.getPartidas().get(1).getObservers().set(0, jugadorSiguiente);
        } else {
            Jugador jugadorSiguiente = (Jugador) AdmPartidas.getPartidas().get(1).getObservers().get(indexAtacante + 1);
            jugadorSiguiente.setTurno(true);
            AdmPartidas.getPartidas().get(1).getObservers().set(indexAtacante + 1, jugadorSiguiente);
            atacante.setTurno(false);
        }
        return true;
    }
}
