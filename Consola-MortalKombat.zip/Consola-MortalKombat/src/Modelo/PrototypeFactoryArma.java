package Modelo;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class PrototypeFactoryArma {
    private static HashMap<String, iPrototype> prototypes = rellenarPrototipos();

    public static HashMap<String, iPrototype> rellenarPrototipos() {
        try {
            HashMap<String, iPrototype> hashMap = new HashMap<>();
            List<Arma> listaArmas = AdminJSON.extraerArmas();
            for (Arma arma : listaArmas) {
                hashMap.put(arma.getNombre(), arma);
            }
            return hashMap;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static iPrototype getPrototype(String nombre) {
        if (nombre != null && prototypes.containsKey(nombre)) {
            return prototypes.get(nombre).deepClone();
        }
        return null;
    }

    public static void addPrototype(String nombre, iPrototype prototype) {
        if (nombre != null && prototype != null && prototypes.containsKey(nombre)) {
            prototypes.put(nombre, prototype);
        }
    }
}
