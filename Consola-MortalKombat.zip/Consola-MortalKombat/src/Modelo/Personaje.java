/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author gabri
 */
public class Personaje implements iPrototype<Personaje>, iPersonaje {
    private String nombre;
    private int nivelPersonaje;
    // determina cuánto daño causa el guerrero al elemento que ataca. Este funciona
    // cuando el personaje NO TIENE ARMA, sino manda el arma.
    private int golpesXSegundo;
    private int numCampos;
    private int nivelAparicion;
    private float costo;
    private int cantidad;
    // El integer será el nivel del personaje para asi asociar la imagen al nivel.
    private List<String> apariencias;
    private HashMap<String, Arma> armas;
    private int vida;
    // Si es true -> no posee arma.
    // Si es false -> posee arma.
    private boolean melee;
    private Arma armaActiva;
    private String aparienciaActiva;
    private Tipo tipo;

    public Personaje() {
    }

    public Personaje(String nombre, int nivelPersonaje, int golpesXSegundo,
            int numCampos, int nivelAparicion, float costo,
            int cantidad, Tipo tipo,
            int vida, boolean melee, Arma armaActiva,
            String aparienciaActiva) {

        this.tipo = tipo;
        this.nombre = nombre;
        this.nivelPersonaje = nivelPersonaje;
        this.golpesXSegundo = golpesXSegundo;
        this.numCampos = numCampos;
        this.nivelAparicion = nivelAparicion;
        this.costo = costo;
        this.cantidad = cantidad;
        this.apariencias = new ArrayList<>();
        this.armas = new HashMap<>();
        this.vida = vida;
        this.melee = melee;
        this.armaActiva = armaActiva;
        this.aparienciaActiva = aparienciaActiva;
    }

    public Personaje(String nombre, int nivelPersonaje, int golpesXSegundo,
            int numCampos, int nivelAparicion, float costo,
            int cantidad, List<String> apariencias,
            HashMap<String, Arma> armas,
            int vida, boolean melee, Arma armaActiva,
            String aparienciaActiva, Tipo tipo) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.nivelPersonaje = nivelPersonaje;
        this.golpesXSegundo = golpesXSegundo;
        this.numCampos = numCampos;
        this.nivelAparicion = nivelAparicion;
        this.costo = costo;
        this.cantidad = cantidad;
        this.apariencias = apariencias;
        this.armas = armas;
        this.vida = vida;
        this.melee = melee;
        this.armaActiva = armaActiva;
        this.aparienciaActiva = aparienciaActiva;
        this.tipo = tipo;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public List<String> getApariencias() {
        return apariencias;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public int getNivelPersonaje() {
        return nivelPersonaje;
    }

    public void setNivelPersonaje(int nivelPersonaje) {
        this.nivelPersonaje = nivelPersonaje;
    }

    public int getGolpesXSegundo() {
        return golpesXSegundo;
    }

    public void setGolpesXSegundo(int golpesXSegundo) {
        this.golpesXSegundo = golpesXSegundo;
    }

    public int getNumCampos() {
        return numCampos;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setNumCampos(int numCampos) {
        this.numCampos = numCampos;
    }

    public int getNivelAparicion() {
        return nivelAparicion;
    }

    public void setNivelAparicion(int nivelAparicion) {
        this.nivelAparicion = nivelAparicion;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getApariencias(int n) {
        return this.apariencias.get(n);
    }

    public void setApariencias(List<String> apariencias) {
        this.apariencias = apariencias;
    }

    public HashMap<String, Arma> getArmas() {
        return armas;
    }

    public void setArmas(HashMap<String, Arma> armas) {
        this.armas = armas;
    }

    public boolean isMelee() {
        return melee;
    }

    public void setMelee(boolean melee) {
        this.melee = melee;
    }

    public Arma getArmaActiva() {
        return armaActiva;
    }

    public void setArmaActiva(Arma armaActiva) {
        this.armaActiva = armaActiva;
    }

    public String getAparienciaActiva() {
        return aparienciaActiva;
    }

    public void setAparienciaActiva(String aparienciaActiva) {
        this.aparienciaActiva = aparienciaActiva;
    }

    public void agregarArma(String nombre) {
        if (nombre != null) {
            Arma cloneArma = (Arma) PrototypeFactoryArma.getPrototype(nombre);
            armas.put(nombre, cloneArma);
        }
    }

    public Arma activarArma(String nombre) {
        if (nombre != null) {
            melee = false;
            agregarArma(nombre);
            armaActiva = getArmas().get(nombre);
        }
        return armaActiva;
    }

    @Override
    public Personaje clone() {

        return new Personaje(nombre, nivelPersonaje, golpesXSegundo,
                numCampos, nivelAparicion, costo,
                cantidad, apariencias,
                armas,
                vida, melee, armaActiva,
                aparienciaActiva, tipo);
    }

    @Override
    public Personaje deepClone() {
        return clone();
    }

    @Override
    public int atacar(Personaje atacado, Arma arma) {
        int danno = arma.determinarDanno(atacado.getTipo().getNombre());
        atacado.setVida(atacado.getVida() - danno);
        return danno;
    }

    @Override
    public void subirNivel() {
        // Se va a incrementar el nivel a todas las armas debido
        // a que el personaje sube de nivel. También, el daño de la misma sube en 15.
        Arma armaActual;
        for (String clave : armas.keySet()) {
            armaActual = armas.get(clave);
            armaActual.setNivelArma(armaActual.getNivelArma() + 1);
            armaActual.setDanno(new int[] { armaActual.getDanno()[0] + 15 });
        }
        // Se incrementa la vida del personaje en 25.
        this.vida = this.vida + 25;
        // Se incrementa el nivel del personaje.
        this.nivelPersonaje = this.nivelPersonaje + 1;
        // Se cambia la apariencia activa.
        aparienciaActiva = getApariencias(this.nivelPersonaje - 1);
    }

    public Arma buscarArma(String arma) {
        if (!"".equals(arma)) {
            Arma armaObj = armas.get(arma);
            return armaObj;
        }
        return null;

    }

    @Override
    public String toString() {
        return "Personaje{" +
                "tipo=" + tipo +
                ", nombre='" + nombre + '\'' +
                ", nivelPersonaje=" + nivelPersonaje +
                ", golpesXSegundo=" + golpesXSegundo +
                ", numCampos=" + numCampos +
                ", nivelAparicion=" + nivelAparicion +
                ", costo=" + costo +
                ", cantidad=" + cantidad +
                ", apariencias=" + apariencias +
                ", armas=" + armas +
                ", vida=" + vida +
                ", melee=" + melee +
                ", armaActiva=" + armaActiva +
                ", aparienciaActiva='" + aparienciaActiva + '\'' +
                '}';
    }
}
