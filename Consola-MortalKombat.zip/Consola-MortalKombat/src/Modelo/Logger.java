package Modelo;
/*
 *
 * @author gmora7
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class Logger implements iLogger {
    private final List<TipoLogger> coleccion;

    public Logger() {
        this.coleccion = new ArrayList<TipoLogger>();
    }
    
    public String insertar(String texto, String nombre){
        
        TipoLogger nuevo = new TipoLogger( texto,nombre, new Date());
        this.coleccion.add(nuevo);
        return texto;
    }

    public List<TipoLogger> getColeccion(){
        return coleccion;
    }
}
