package Modelo;

public interface iPersonaje {
    public int atacar(Personaje atacado, Arma arma);

    public void subirNivel();
}
