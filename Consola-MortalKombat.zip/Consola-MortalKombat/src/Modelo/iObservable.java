/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Modelo;

/**
 *
 * @author Kevin
 */
public interface iObservable {
    public void addObserver(iObserver observer);

    public void removeObserver(iObserver observer);

    public void notifyAllObservers(String command, Object source);
}
