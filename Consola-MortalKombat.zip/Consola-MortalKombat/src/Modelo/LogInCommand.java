package Modelo;

import Control.AdmPartidas;

public class LogInCommand implements ICommand {
    public static final String COMMAND_NAME = "LOGUEARSE";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean crearJugador(String nickname, String activacion) {
        Jugador jugadorTmp = AdmPartidas.getPartidas().get(1).buscarJugador(nickname);
        if (jugadorTmp == null) { // Signica que no existe.
            Jugador jugador = new Jugador(nickname);
            if (activacion.equals("activar")) {
                jugador.setTurno(true);
            }
            jugador.unirsePartida(AdmPartidas.getPartidas().get(1));
            AdmPartidas.getPartidas().get(1).addObserver(jugador);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean execute(String[] args, Jugador jugador) {
        String nickname;
        nickname = args[1];
        String activacion = args[2];
        boolean respuesta = crearJugador(nickname, activacion);
        return respuesta;
    }
}
