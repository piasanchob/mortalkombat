package Modelo;

import Control.AdmPartidas;
import Control.AdmScoresXPartida;

public class AttackCommand implements ICommand {
    public static final String COMMAND_NAME = "ATTACK";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean atacar(Jugador atacante, String nombrePersonaje,
            String nombreArma,
            String nombreJugadorAtacado) {
        // Se valida que el personaje del atacante exista.
        Personaje personajeAtacante = atacante.getEjercito().get(nombrePersonaje);
        if (personajeAtacante != null) {
            Arma arma = personajeAtacante.buscarArma(nombreArma);
            // Se valida que el nombre del arma del atacante exista y que no haya sido
            // utilizada. Donde activa == usada.
            if (arma != null && !arma.isActiva()) {
                Jugador atacado = AdmPartidas.getPartidas().get(1)
                        .buscarJugador(nombreJugadorAtacado);
                if (atacado != null) {
                    // Se atacan a los personajes del enemigo.
                    int dannoRealizado = atacante.atacarEjercito(atacado, arma);
                    ScoresXPartida scoreTmp = AdmScoresXPartida.existePartida(atacante, atacado);
                    if (scoreTmp != null) {// YA EXISTE HISTORIAL ENTRE ELLOS
                        scoreTmp.actualizar(atacante, atacado);
                        AdmScoresXPartida.actualizarEstadisticas(scoreTmp);
                    } else {
                        AdmScoresXPartida.agregarPartida(atacante, atacado);// NO EXISTE UN HISTORIAL
                        // ENTRE ELLOS, ENTONCES SE CREA UNO.
                        scoreTmp = AdmScoresXPartida.existePartida(atacante, atacado);
                        scoreTmp.actualizar(atacante, atacado);
                        AdmScoresXPartida.actualizarEstadisticas(scoreTmp);
                        System.out.println(AdmScoresXPartida.getScores().get(0));
                    }
                    // enviar a atacante y atacado, la info del ataque
                    AdmPartidas.getPartidas().get(1)
                            .notifyAllObservers("enviarMensaje",
                                    "El jugador " + atacado.getNombre()
                                            + " ha sido atacado y se le resto la vida un "
                                            + dannoRealizado + "%");
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes((Integer.toString(dannoRealizado)));

                    return true;
                } else { // error de que el jugador al que quiere atacar no existe
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes("El jugador enemigo no existe.");
                    System.out.println("El jugador enemigo no existe.");
                }
            } else { // error de que el personajo ya usó o no tiene el arma
                AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                        .addMensajes("El arma ya fue usada.");
                System.out.println("El arma ya fue usada.");
                return false;
            }
        } else { // error de que no tiene el personaje
            AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                    .addMensajes("El personaje indicado no existe.");
            System.out.println("El personaje indicado no existe.");
        }
        return false;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String nombreAtacado = args[1];
        String nombrePersonaje = args[2];
        String nombreArma = args[3];
        boolean respuesta = atacar(atacante,
                nombrePersonaje, nombreArma, nombreAtacado);
        return respuesta;
    }
}
