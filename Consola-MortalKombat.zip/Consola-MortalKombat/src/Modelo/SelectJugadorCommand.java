package Modelo;

import Control.AdmPartidas;
import Control.AdmScoresXPartida;

public class SelectJugadorCommand implements ICommand {
    public static final String COMMAND_NAME = "SELECT";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean validarJugador(Jugador jugador, String nickname) {
        Jugador jugadorTmp = AdmPartidas.getPartidas().get(1).buscarJugador(nickname);
        if (jugadorTmp != null) {
            ScoresXPartida scores = AdmScoresXPartida.existePartida(jugador, jugadorTmp);
            if (scores != null) {
                System.out.println("entra a selectJugador");
                String mensaje = "Contra: " + nickname +
                        "\n Ganes: " + scores.getGanes() +
                        "\n Perdidas: " + scores.getPerdidas() +
                        "\n Ataques Exitosos: " + scores.getAtaquesExitosos() +
                        "\n Ataques Fracasados: " + scores.getAtaquesFracasados() +
                        "\n Ataques: " + (scores.getAtaquesFracasados() + scores.getAtaquesExitosos()) +
                        "\n Rendiciones: " + scores.getRendiciones();
                System.out.println(mensaje);
                AdmPartidas.getPartidas().get(1).buscarJugador(jugador.getNombre()).addMensajes(mensaje);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean execute(String[] args, Jugador jugador) {
        String nickname;
        nickname = args[1];
        boolean respuesta = validarJugador(jugador, nickname);
        return respuesta;
    }
}