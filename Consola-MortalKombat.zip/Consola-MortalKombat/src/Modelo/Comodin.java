/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author gabri
 */
public class Comodin {
    private Jugador jugador;

    public Comodin(Jugador jugador) {
        this.jugador = jugador;
    }

    public void empezarTimer() {
        Timer timer = new Timer();
        Random random = new Random();
        TimerTask timerTask = new TimerTask() {
            public void run() {
                int rand;
                while (true) {
                    rand = random.nextInt(3) - 1;
                    if (rand == 1 || rand == -1)
                        break;
                }
                if (rand > 0) {
                    jugador.setComodin(true);

                } else {
                    jugador.setComodin(false);
                }
                System.out.println("El comodin de " + jugador.getNombre() + " es: "+ jugador.isComodin());
            }
        };
        // 5 minutos son 300000, pero se puso 60000 que es un minuto para la revisión.
        timer.scheduleAtFixedRate(timerTask, 0, 60000);
    }
}
