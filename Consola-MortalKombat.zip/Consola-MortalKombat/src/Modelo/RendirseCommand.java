package Modelo;

import Control.AdmPartidas;

/**
 *
 * @author gabri
 */
public class RendirseCommand implements ICommand {
    public static final String COMMAND_NAME = "RENDIRSE";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        AdmPartidas.getPartidas().get(1).notifyAllObservers("enviarMensaje",
                "El jugador " + atacante.getNombre() + " ha salido de la partida por rendicion");// MANDA EL NOMBRE DEL
                                                                                                 // JUGADOR, Y
        // COMO YA ERA MIEMBRO DE ESA PARTIDA
        AdmPartidas.getPartidas().get(1).removeObserver(atacante);
        atacante.eliminarPartida();
        atacante.addMensajes("Has salido de la partida.");
        System.out.println("Se elimino la partida al jugador " + atacante.getNombre());
        return true;

    }
}