package Modelo;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;

public class VerArchivoCommand implements ICommand {
    public static final String COMMAND_NAME = "VERARCHIVO";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String nombre = atacante.getNombre();
        try (FileReader file = new FileReader(nombre + ".txt")) {
            BufferedReader reader = new BufferedReader(file);
            String texto = "";
            String line = reader.readLine();
            while (line != null) {
                texto += line + "\n";
                line = reader.readLine();
            }
            atacante.addMensajes(texto);
            return true;
        } catch (final IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
