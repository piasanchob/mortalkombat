package Modelo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gabri
 */
public class AdminJSON {

    public AdminJSON() {
    }

    public static List<Personaje> extraerPersonajes() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File(System.getProperty("user.dir") + "\\personajes.json");
        JsonNode jsonArray = objectMapper.readValue(file, JsonNode.class);
        String jsonArrayAsString = objectMapper.writeValueAsString(jsonArray);
        List<Personaje> listaPersonajes = objectMapper.readValue(jsonArrayAsString,
                new TypeReference<List<Personaje>>() {
                });
        return listaPersonajes;

    }

    public static List<Arma> extraerArmas() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        File file = new File(System.getProperty("user.dir") + "\\armas.json");
        JsonNode jsonArray = objectMapper.readValue(file, JsonNode.class);
        String jsonArrayAsString = objectMapper.writeValueAsString(jsonArray);
        List<Arma> listaArmas = objectMapper.readValue(jsonArrayAsString,
                new TypeReference<List<Arma>>() {
                });
        return listaArmas;

    }
}
