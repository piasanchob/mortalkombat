package Modelo;

import java.util.List;
import java.util.ArrayList;

public class RecargarCommand implements ICommand {
    public static final String COMMAND_NAME = "RECARGAR";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    // Se encarga de verificar que todas las armas de los personajes hayan sido
    // usadas.
    public boolean sonActivas(List<Personaje> personajes) {
        int i = 0;
        boolean flag = false;
        while (i < personajes.size()) {
            List<Arma> armas = new ArrayList<Arma>(personajes.get(i).getArmas().values());
            int j = 0;
            while (j < 5) {
                if (!armas.get(i).isActiva()) {
                    flag = true;
                    break;
                }
                j++;
            }
            i++;
        }
        return flag;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        List<Personaje> personajes = new ArrayList<Personaje>(atacante.getEjercito().values());
        if (atacante.getPartidas().get(1).isActiva()) {
            boolean flag = sonActivas(personajes);
            if (flag == false) {
                int i = 0;
                while (i < personajes.size()) {
                    List<Arma> armas = new ArrayList<Arma>(personajes.get(i).getArmas().values());
                    personajes.get(i).getArmas().get(armas.get(0).getNombre()).setActiva(false);
                    personajes.get(i).getArmas().get(armas.get(1).getNombre()).setActiva(false);
                    personajes.get(i).getArmas().get(armas.get(2).getNombre()).setActiva(false);
                    personajes.get(i).getArmas().get(armas.get(3).getNombre()).setActiva(false);
                    personajes.get(i).getArmas().get(armas.get(4).getNombre()).setActiva(false);
                    i++;
                }
                atacante.getEjercito().replace(personajes.get(0).getNombre(), personajes.get(0));
                atacante.getEjercito().replace(personajes.get(1).getNombre(), personajes.get(1));
                atacante.getEjercito().replace(personajes.get(2).getNombre(), personajes.get(2));
                atacante.getEjercito().replace(personajes.get(3).getNombre(), personajes.get(3));
                atacante.addMensajes("Se recargaron las armas");
                return true;
            } else {
                atacante.addMensajes("Todavía tiene armas por usar");
                System.out.println("Todavía tiene armas por usar");
            }
        }
        return false;
    }
}
