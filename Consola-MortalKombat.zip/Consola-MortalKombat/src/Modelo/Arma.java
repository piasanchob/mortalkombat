/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 *
 * @author gabri
 */
public class Arma implements iPrototype<Arma> {
    private String nombre;
    private int[] danno;
    private boolean poder;
    private int rangoExplosion;
    private int alcance;
    private boolean activa;
    private int nivelArma;
    private float costo;
    private List<String> apariencias;

    public Arma() {
    }

    public Arma(String nombre, int[] danno, boolean poder, int rangoExplosion,
            int alcance, boolean activa, int nivelArma, int nivelAparicion,
            float costo, List<String> apariencia) {
        this.nombre = nombre;
        this.danno = new int[10];
        this.setDanno();// Cada vez que se crea un arma de una vez crea el array con valores aleatorios
        this.poder = poder;
        this.rangoExplosion = rangoExplosion;
        this.alcance = alcance;
        this.activa = activa;
        this.nivelArma = nivelArma;
        this.costo = costo;
        this.apariencias = apariencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int[] getDanno() {
        return danno;
    }

    public void setDanno(int[] danno) {
        this.danno = danno;
    }

    public void setDanno() {// SET DANNO ALEATORIAMENTE PARA LOS 10 TIPOS
        int i = 0;
        Random r = new Random();
        while (i < 10) {
            int dannoRandom = r.nextInt(80) + 20;
            this.danno[i] = dannoRandom;
            i++;
        }
    }

    public boolean isPoder() {
        return poder;
    }

    public void setPoder(boolean poder) {
        this.poder = poder;
    }

    public int getRangoExplosion() {
        return rangoExplosion;
    }

    public void setRangoExplosion(int rangoExplosion) {
        this.rangoExplosion = rangoExplosion;
    }

    public int getAlcance() {
        return alcance;
    }

    public void setAlcance(int alcance) {
        this.alcance = alcance;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    public int getNivelArma() {
        return nivelArma;
    }

    public void setNivelArma(int nivelArma) {
        this.nivelArma = nivelArma;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public List<String> getApariencias() {
        return apariencias;
    }

    public void setApariencia(List<String> apariencias) {
        this.apariencias = apariencias;
    }

    public int determinarDanno(String tipo) {
        int danno;
        switch (tipo) {
            case "Acido":
                danno = this.danno[0];
                break;
            case "Aire":
                danno = this.danno[1];
                break;
            case "Agua":
                danno = this.danno[2];
                break;
            case "Electricidad":
                danno = this.danno[3];
                break;
            case "Magia negra":
                danno = this.danno[4];
                break;
            case "Fuego":
                danno = this.danno[5];
                break;
            case "Magia blanca":
                danno = this.danno[6];
                break;
            case "Hielo":
                danno = this.danno[7];
                break;
            case "Hierro":
                danno = this.danno[8];
                break;
            case "Espiritualidad":
                danno = this.danno[9];
                break;
            default:
                danno = -1;
                break;
        }
        return danno;
    }

    @Override
    public String toString() {
        return "Arma{" + "nombre=" + nombre + ", danno=" + Arrays.toString(danno) +
                ", poder=" + poder + ", rangoExplosion=" + rangoExplosion +
                ", alcance=" + alcance + ", activa=" + activa +
                ", nivelArma=" + nivelArma + ", costo=" + costo +
                ", apariencias=" + apariencias + '}';
    }

    @Override
    public Arma clone() {
        return new Arma(nombre, danno, poder, rangoExplosion, alcance,
                activa, nivelArma, nivelArma, costo,
                apariencias);
    }

    @Override
    public Arma deepClone() {
        return clone();
    }

}
