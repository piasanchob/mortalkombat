package Modelo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Jugador implements iObserver {
    private boolean turno;
    private String nombre;
    private int nivel;
    private float wallet;
    private HashMap<String, Personaje> personajesDesbloqueados;
    private int capacidad;
    private int actual; // Indica la cantidad de espacios ocupados.
    private HashMap<String, Personaje> ejercito;
    private HashMap<Integer, Partida> partidas;
    private List<String> mensajes;
    private boolean comodin;
    private boolean salidaMutua;
    private Scores scorePersonal;

    public Jugador(String nombre, int nivel, float wallet,
            HashMap<String, Personaje> personajesDesbloqueados,
            int capacidad, int actual,
            HashMap<String, Personaje> ejercito, int id,
            int score) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.wallet = wallet;
        this.personajesDesbloqueados = personajesDesbloqueados;
        this.capacidad = capacidad;
        this.actual = actual;
        this.ejercito = ejercito;
        this.partidas = new HashMap<>();
        this.mensajes = new ArrayList<>();
        this.comodin = false;
        this.turno = false;
        this.salidaMutua = false;
        this.scorePersonal = new Scores();
    }

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.nivel = 1;
        this.wallet = 0;
        this.personajesDesbloqueados = new HashMap<>();
        this.capacidad = 1;
        this.actual = 0;
        this.ejercito = new HashMap<>();
        this.partidas = new HashMap<>();
        this.mensajes = new ArrayList<>();
        this.comodin = true;
        this.turno = false;
        this.scorePersonal = new Scores();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public float getWallet() {
        return wallet;
    }

    public void setWallet(float wallet) {
        this.wallet = wallet;
    }

    public HashMap<String, Personaje> getPersonajesDesbloqueados() {
        return personajesDesbloqueados;
    }

    public void setPersonajesDesbloqueados(HashMap<String, Personaje> personajesDesbloqueados) {
        this.personajesDesbloqueados = personajesDesbloqueados;
    }

    public void setPartidas(HashMap<Integer, Partida> partidas) {
        this.partidas = partidas;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getActual() {
        return actual;
    }

    public void setActual(int actual) {
        this.actual = actual;
    }

    public HashMap<String, Personaje> getEjercito() {
        return ejercito;
    }

    public void setEjercito(HashMap<String, Personaje> ejercito) {
        this.ejercito = ejercito;
    }

    public void addPersonajesDesbloqueados(String nombre) {
        if (nombre != null) {
            Personaje clonePersonaje = (Personaje) PrototypeFactoryPersonaje.getPrototype(nombre);
            this.personajesDesbloqueados.put(nombre, clonePersonaje);
        }
    }

    public Personaje addEjercito(String personaje) {
        if (personaje != null) {
            Personaje clonePersonaje = (Personaje) PrototypeFactoryPersonaje.getPrototype(personaje);
            this.ejercito.put(personaje, clonePersonaje);
            return clonePersonaje;
        }
        return null;
    }

    public void unirsePartida(Partida partida) {
        if (partida != null) {
            partidas.put(partida.getId(), partida);
        }
    }

    public void eliminarPartida() {
        if (this.partidas.isEmpty() == false) {
            partidas.remove(1);
        }
    }

    public void actualizarPartida(Partida partida) {
        if (partida != null) {
            partidas.replace(partida.getId(), partida);
        }
    }

    public HashMap<Integer, Partida> getPartidas() {
        return partidas;
    }

    public void setMensajes(List<String> mensajes) {
        this.mensajes = mensajes;
    }

    public List<String> getMensajes() {
        return mensajes;
    }

    public void addMensajes(String mensaje) {
        this.mensajes.add(mensaje);
    }

    public boolean isComodin() {
        return comodin;
    }

    public void setComodin(boolean comodin) {
        this.comodin = comodin;
    }

    public boolean isTurno() {
        return turno;
    }

    public void setTurno(boolean turno) {
        this.turno = turno;
    }

    public boolean isSalidaMutua() {
        return salidaMutua;
    }

    public void setSalidaMutua(boolean salidaMutua) {
        this.salidaMutua = salidaMutua;
    }

    public void setscorePersonal(Scores score) {
        this.scorePersonal = score;
    }

    public Scores getscorePersonal() {
        return scorePersonal;
    }

    public int atacarEjercito(Jugador atacado, Arma arma) {
        int dannoRealizado = 0;
        for (HashMap.Entry<String, Personaje> personaje : atacado.getEjercito().entrySet()) {
            Personaje personajeEnemigo = personaje.getValue();
            int danno = arma.determinarDanno(personajeEnemigo.getTipo().getNombre());
            personajeEnemigo.setVida(personajeEnemigo.getVida() - danno);
            dannoRealizado += danno;
        }
        arma.setActiva(true);
        return dannoRealizado;
    }

    public int obtenerVidaJugador() {
        int vidaTotal = 0;
        for (HashMap.Entry<String, Personaje> personaje : getEjercito().entrySet()) {
            Personaje personajeTmp = personaje.getValue();
            int vida = personajeTmp.getVida();
            vidaTotal += vida;
        }
        return vidaTotal;
    }

    public int obtenerMuertesJugador() {
        int muertes = 0;
        for (HashMap.Entry<String, Personaje> personaje : getEjercito().entrySet()) {
            Personaje personajeTmp = personaje.getValue();
            int vida = personajeTmp.getVida();
            if (vida <= 0) {
                muertes++;
            }
        }
        return muertes;
    }

    @Override
    public void notifyObserver(String command, Object source) {
        if (command.equalsIgnoreCase("enviarMensaje")) {
            String mensaje = (String) source;
            addMensajes(mensaje);
        } else {
            // Sucede cuando existe.
            Partida partida = (Partida) source;
            if (command == this.nombre && this.partidas.isEmpty() == true) {
                unirsePartida(partida);
            }
        }
    }

    @Override
    public String toString() {
        return "Jugador [nombre=" + nombre
                + ", nivel=" + nivel + ", wallet=" + wallet
                + ", personajesDesbloqueados=" + personajesDesbloqueados
                + ", capacidad=" + capacidad + ", actual="
                + actual + ", ejercito=" + ejercito + ", partidas="
                + partidas + ", mensajes=" + mensajes + ", comodin="
                + comodin + ", scorePersonal=" + scorePersonal + "]";
    }

}
