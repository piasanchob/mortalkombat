package Modelo;

/**
 *
 * @author Kevin
 */
import java.util.ArrayList;
import java.util.List;

public abstract class AbstractObservable implements iObservable {
    protected final List<iObserver> observers = new ArrayList<>(); // Vendrian siendo los jugadores.

    public List<iObserver> getObservers() {
        return observers;
    }

    @Override
    public void addObserver(iObserver iObserver) {
        this.observers.add(iObserver);
    }

    @Override
    public void removeObserver(iObserver observer) {
        this.observers.remove(observer);

    }

    @Override
    public void notifyAllObservers(String command, Object source) {
        for (iObserver observer : observers) {
            observer.notifyObserver(command, source);
        }
    }

    @Override
    public String toString() {
        return "AbstractObservable{" + "observers=" + observers + '}';
    }
}
