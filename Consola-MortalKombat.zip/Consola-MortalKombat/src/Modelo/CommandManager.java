package Modelo;

import java.util.HashMap;

public class CommandManager {
    private static CommandManager commandManager;
    private static final HashMap<String, Class<? extends ICommand>> COMMANDS = new HashMap<String, Class<? extends ICommand>>();

    private CommandManager() {
        registCommand(AttackCommand.COMMAND_NAME, AttackCommand.class);
        registCommand(ComodinCommand.COMMAND_NAME, ComodinCommand.class);
        registCommand(RendirseCommand.COMMAND_NAME, RendirseCommand.class);
        registCommand(ChatPrivadoCommand.COMMAND_NAME, ChatPrivadoCommand.class);
        registCommand(RecargarCommand.COMMAND_NAME, RecargarCommand.class);
        registCommand(ChatPublicoCommand.COMMAND_NAME, ChatPublicoCommand.class);
        registCommand(SalidaMutuaCommand.COMMAND_NAME, SalidaMutuaCommand.class);
        registCommand(EleccionPersonajeCommand.COMMAND_NAME, EleccionPersonajeCommand.class);
        registCommand(LogInCommand.COMMAND_NAME, LogInCommand.class);
        registCommand(TurnoCommand.COMMAND_NAME, TurnoCommand.class);
        registCommand(VerArchivoCommand.COMMAND_NAME, VerArchivoCommand.class);
        registCommand(SelectJugadorCommand.COMMAND_NAME, SelectJugadorCommand.class);
        registCommand(MyStatusCommand.COMMAND_NAME, MyStatusCommand.class);
        registCommand(RankingCommand.COMMAND_NAME, RankingCommand.class);
        registCommand(VerUltimoAtaqueCommand.COMMAND_NAME, VerUltimoAtaqueCommand.class);
    }

    public static synchronized CommandManager getIntance() {
        if (commandManager == null) {
            commandManager = new CommandManager();
        }
        return commandManager;
    }

    public ICommand getCommand(String commandName) {
        if (COMMANDS.containsKey(commandName.toUpperCase())) {
            try {
                return COMMANDS.get(commandName.toUpperCase()).newInstance();
            } catch (Exception e) {
                e.printStackTrace();
                return null;// cambiar
            }
        } else {
            return null;// cambiar
        }
    }

    public void registCommand(String commandName, Class<? extends ICommand> command) {
        COMMANDS.put(commandName.toUpperCase(), command);
    }
}
