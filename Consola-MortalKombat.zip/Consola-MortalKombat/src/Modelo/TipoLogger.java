package Modelo;

import java.util.Date;

public class TipoLogger {
    
    private String texto; //NVARCHAR(MAX) ?
    private String nombre;
    private Date fecha;



    public TipoLogger( String texto,String nombre ,Date fecha) {
        this.texto = texto;
        this.nombre= nombre;
        this.fecha = fecha;
    }


    public String getTexto() {
        return texto;
    }



    public void setTexto(String texto) {
        this.texto = texto;
    }



    public Date getFecha() {
        return fecha;
    }



    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }



    @Override
    public String toString() {
        return "TipoLogger [ texto=" + texto + ", fecha=" + fecha + "]";
    }


    public String getNombre() {
        return nombre;
    }


    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
