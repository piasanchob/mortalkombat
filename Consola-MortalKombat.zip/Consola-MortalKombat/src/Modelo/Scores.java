package Modelo;

public class Scores {
    private int ataquesExitosos;
    private int ataquesFracasados;
    private int muertes;
    private int ganes;
    private int perdidas;
    private int rendiciones;
    private int ataques;

    public Scores() {
        this.ataquesExitosos = 0;
        this.ataquesFracasados = 0;
        this.muertes = 0;
        this.ganes = 0;
        this.perdidas = 0;
        this.rendiciones = 0;
        this.ataques = 0;
    }

    public int getAtaquesExitosos() {
        return ataquesExitosos;
    }

    public void setAtaquesExitosos(int ataquesExitosos) {
        this.ataquesExitosos = ataquesExitosos;
    }

    public int getAtaquesFracasados() {
        return ataquesFracasados;
    }

    public void setAtaquesFracasados(int ataquesFracasados) {
        this.ataquesFracasados = ataquesFracasados;
    }

    public int getMuertes() {
        return muertes;
    }

    public void setMuertes(int muertes) {
        this.muertes = muertes;
    }

    public int getGanes() {
        return ganes;
    }

    public void setGanes(int ganes) {
        this.ganes = ganes;
    }

    public int getPerdidas() {
        return perdidas;
    }

    public void setPerdidas(int perdidas) {
        this.perdidas = perdidas;
    }

    public int getRendiciones() {
        return rendiciones;
    }

    public void setRendiciones(int rendiciones) {
        this.rendiciones = rendiciones;
    }

    public void setAtaques(int ataques) {
        this.ataques = ataques;
    }

    public int getAtaques() {
        return ataques;
    }

    @Override
    public String toString() {
        return "Scores{" +
                "ataquesExitosos=" + ataquesExitosos +
                ", ataquesFracasados=" + ataquesFracasados +
                ", muertes=" + muertes +
                ", ganes=" + ganes +
                ", perdidas=" + perdidas +
                ", rendiciones=" + rendiciones +
                '}';
    }
}