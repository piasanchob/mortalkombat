package Modelo;

public class ScoresXPartida {
    private Jugador atacante;
    private Jugador atacado;
    private int ataquesExitosos;
    private int ataquesFracasados;
    private int muertes;
    private int ganes;
    private int perdidas;
    private int rendiciones;

    public ScoresXPartida(Jugador atacante, Jugador atacado) {
        this.atacante = atacante;
        this.atacado = atacado;
        this.ataquesExitosos = 0;
        this.ataquesFracasados = 0;
        this.muertes = 0;
        this.ganes = 0;
        this.perdidas = 0;
        this.rendiciones = 0;
    }

    public int getAtaquesExitosos() {
        return ataquesExitosos;
    }

    public void setAtaquesExitosos(int ataquesExitosos) {
        this.ataquesExitosos = ataquesExitosos;
    }

    public int getAtaquesFracasados() {
        return ataquesFracasados;
    }

    public void setAtaquesFracasados(int ataquesFracasados) {
        this.ataquesFracasados = ataquesFracasados;
    }

    public int getMuertes() {
        return muertes;
    }

    public void setMuertes(int muertes) {
        this.muertes = muertes;
    }

    public int getGanes() {
        return ganes;
    }

    public void setGanes(int ganes) {
        this.ganes = ganes;
    }

    public int getPerdidas() {
        return perdidas;
    }

    public void setPerdidas(int perdidas) {
        this.perdidas = perdidas;
    }

    public int getRendiciones() {
        return rendiciones;
    }

    public void setRendiciones(int rendiciones) {
        this.rendiciones = rendiciones;
    }

    public void setAtacante(Jugador atacante) {
        this.atacante = atacante;
    }

    public Jugador getAtacante() {
        return atacante;
    }

    public void setAtacado(Jugador atacado) {
        this.atacado = atacado;
    }

    public Jugador getAtacado() {
        return atacado;
    }
    
    public void actualizar(Jugador atacante, Jugador atacado){
        atacante.getscorePersonal().setAtaques(atacante.getscorePersonal().getAtaques() + 1);// SE LE SUMA UN ATAQUE AL HISTORIAL DEL JUGADOR.
        int vida = atacado.obtenerVidaJugador();
        if(vida <= 0){
            atacante.getscorePersonal().setGanes(atacante.getscorePersonal().getGanes() + 1);//SE ACTUALIZA EL GANE AL GANADOR EN SUS ESTADISTICAS PERSONALES
            atacado.getscorePersonal().setPerdidas(atacado.getscorePersonal().getPerdidas() + 1);//SE ACTUALIZA LA PERDIDA AL ATACADO EN SUS ESTADISTICAS PERSONALES
            setGanes(getGanes() + 1);//SE ACTUALIZA EL GANE DEL ATACANTE AL HISTORIAL ENTRE AMBOS
            atacante.getscorePersonal().setAtaquesExitosos(atacante.getscorePersonal().getAtaquesExitosos() + 1);// SE LE SUMA UN ATAQUE EXITOSO AL HISTORIAL DEL JUGADOR DEBIDO A QUE MATO AL OTRO
            setAtaquesExitosos(getAtaquesExitosos()+1);//SE LE SUMA UN ATAQUE EXITOSO AL HISTORIAL ENTRE AMBOS.
        }
        else{
            atacante.getscorePersonal().setAtaquesFracasados(atacante.getscorePersonal().getAtaquesFracasados() + 1);// SE LE SUMA UN ATAQUE FRACASADO AL HISTORIAL DEL JUGADOR DEBIDO A QUE NO MATO AL OTRO
            setAtaquesFracasados(getAtaquesFracasados()+1);//SE LE SUMA UN ATAQUE FRACASADO AL HISTORIAL ENTRE AMBOS.
        }
        int muertes = atacado.obtenerMuertesJugador();
        atacante.getscorePersonal().setMuertes(atacante.getscorePersonal().getMuertes() + muertes);
        setMuertes(getMuertes() + muertes);
    }
}