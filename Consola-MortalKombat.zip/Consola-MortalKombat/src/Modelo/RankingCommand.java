package Modelo;

import Control.AdmPartidas;

public class RankingCommand implements ICommand {
    public static final String COMMAND_NAME = "RANKING";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean validarJugador(Jugador jugador) {
        int sizeObservers = AdmPartidas.getPartidas().get(1).getObservers().size();
        int i = 0;
        int[][] almacenado = new int[sizeObservers][4];
        while (i < sizeObservers) {
            Jugador jugadorTmp = (Jugador) AdmPartidas.getPartidas().get(1).getObservers().get(i);
            int exitosos = jugadorTmp.getscorePersonal().getAtaquesExitosos();
            int fracasos = jugadorTmp.getscorePersonal().getAtaquesFracasados();
            almacenado[i][0] = exitosos;
            almacenado[i][1] = fracasos;
            almacenado[i][2] = exitosos - fracasos;
            almacenado[i][3] = i;// POSICION EN LA LISTA ORIGINAL PARA OBTENER EL NOMBRE DESPUES
            i++;
        }
        i = 0;
        for (i = 0; i < sizeObservers; i++) {
            for (int x = 0; x < sizeObservers; x++) {
                if (almacenado[i][2] > almacenado[x][2]) {
                    int t = almacenado[i][3];
                    int t1 = almacenado[i][2];
                    int t2 = almacenado[i][1];
                    int t3 = almacenado[i][0];
                    almacenado[i][3] = almacenado[x][3];
                    almacenado[i][2] = almacenado[x][2];
                    almacenado[i][1] = almacenado[x][1];
                    almacenado[i][0] = almacenado[x][0];
                    almacenado[x][3] = t;
                    almacenado[x][2] = t1;
                    almacenado[x][1] = t2;
                    almacenado[x][0] = t3;
                }
            }
        }
        String mensaje = "Ranking";
        int cont = 0;
        int cont2 = 1;
        while (cont < sizeObservers) {
            Jugador jugadorTmp = (Jugador) AdmPartidas.getPartidas().get(1).getObservers().get(almacenado[cont][3]);
            mensaje += "\n " + cont2 + ". " + jugadorTmp.getNombre() + " [" + almacenado[cont][0] + "/"
                    + almacenado[cont][1] + "]";
            cont++;
            cont2++;
        }
        System.out.println(mensaje);
        AdmPartidas.getPartidas().get(1).buscarJugador(jugador.getNombre()).addMensajes(mensaje);
        return true;
    }

    @Override
    public boolean execute(String[] args, Jugador jugador) {
        boolean respuesta = validarJugador(jugador);
        return respuesta;
    }
}