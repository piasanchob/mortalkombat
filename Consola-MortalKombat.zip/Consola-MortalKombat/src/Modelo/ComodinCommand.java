package Modelo;

import Control.AdmPartidas;
import Control.AdmScoresXPartida;

/**
 *
 * @author gabri
 */
public class ComodinCommand implements ICommand {
    public static final String COMMAND_NAME = "COMODIN";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean atacarConComodin(Jugador atacante, String nombrePersonaje,
            String nombreArma, String nombreJugadorAtacado,
            String nombrePersonaje2, String nombreArma2) {
        // Se valida que el personaje del atacante exista.
        Personaje personajeAtacante = atacante.getEjercito().get(nombrePersonaje);
        Personaje personajeAtacante2 = atacante.getEjercito().get(nombrePersonaje2);
        if (personajeAtacante != null && personajeAtacante2 != null) {
            Arma arma = personajeAtacante.buscarArma(nombreArma);
            Arma arma2 = personajeAtacante2.buscarArma(nombreArma2);
            // Se valida que el nombre del arma del atacante exista y que no haya sido
            // utilizada.
            if (arma != null && arma2 != null && arma.isActiva() == false
                    && arma2.isActiva() == false) {
                Jugador atacado = AdmPartidas.getPartidas().get(1)
                        .buscarJugador(nombreJugadorAtacado);
                if (atacado != null) {
                    // Se atacan a los personajes del enemigo.
                    int dannoRealizado = atacante.atacarEjercito(atacado, arma);
                    int dannoRealizado2 = atacante.atacarEjercito(atacado, arma2);
                    int dannoTotal = dannoRealizado + dannoRealizado2;
                    ScoresXPartida scoreTmp = AdmScoresXPartida.existePartida(atacante, atacado);
                    if (scoreTmp != null) {// YA EXISTE HISTORIAL ENTRE ELLOS
                        scoreTmp.actualizar(atacante, atacado);
                        AdmScoresXPartida.actualizarEstadisticas(scoreTmp);
                    } else {
                        AdmScoresXPartida.agregarPartida(atacante, atacado);// NO EXISTE UN HISTORIAL
                        // ENTRE ELLOS, ENTONCES SE CREA UNO.
                        scoreTmp = AdmScoresXPartida.existePartida(atacante, atacado);
                        scoreTmp.actualizar(atacante, atacado);
                        AdmScoresXPartida.actualizarEstadisticas(scoreTmp);
                    }
                    // enviar a atacante y atacado, la info del ataque
                    AdmPartidas.getPartidas().get(1).notifyAllObservers("enviarMensaje",
                            "El jugador " + atacado.getNombre()
                                    + " ha sido atacado CON COMODIN y se le resto la vida un "
                                    + dannoTotal + "%");
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes("Se ataco a " + atacado.getNombre() + " con " +
                                    nombrePersonaje + " " +
                                    personajeAtacante.getTipo().getNombre() +
                                    " y " + nombrePersonaje2 + " " +
                                    personajeAtacante2.getTipo().getNombre());
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes("Armas: " + arma.getNombre() + " " + arma2.getNombre());
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes(Integer.toString(dannoTotal));
                    return true;
                } else { // error de que el jugador al que quiere atacar no existe
                    AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                            .addMensajes("El jugador enemigo no existe.");
                    System.out.println("El jugador enemigo no existe.");
                }
            } else { // error de que el personajo ya usó o no tiene el arma
                AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                        .addMensajes("El arma ya fue usada.");
                System.out.println("El arma ya fue usada.");
            }
        } else { // error de que no tiene el personaje
            AdmPartidas.getPartidas().get(1).buscarJugador(atacante.getNombre())
                    .addMensajes("El personaje indicado no existe.");
            System.out.println("El personaje indicado no existe.");
        }
        return false;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String nombreJugadorAtacado = args[2];
        String nombrePersonaje = args[3];
        String nombreArma = args[4];
        String nombrePersonaje2 = args[5];
        String nombreArma2 = args[6];
        boolean respuesta = false;
        if (atacante.isComodin()) {
            respuesta = atacarConComodin(atacante, nombrePersonaje,
                    nombreArma, nombreJugadorAtacado, nombrePersonaje2,
                    nombreArma2);
        } else {
            System.out.println("No se puede usar el comodin.");
        }
        return respuesta;
    }
}
