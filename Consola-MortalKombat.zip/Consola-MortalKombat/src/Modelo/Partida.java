package Modelo;

import java.util.HashMap;

public class Partida extends AbstractObservable {
    private int id;
    private final HashMap<Integer, String> mensajes;
    private boolean activa; // La partida esta en curso true sino false
    private boolean hayPrimerJugador;

    public Partida(int id) {
        this.id = id;
        this.mensajes = new HashMap<>();
        this.activa = true;
        this.hayPrimerJugador = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void agregarMensaje(int idMensaje, String contexto) {
        this.mensajes.put(idMensaje, contexto);
    }

    public boolean isHayPrimerJugador() {
        return hayPrimerJugador;
    }

    public void setHayPrimerJugador(boolean hayPrimerJugador) {
        this.hayPrimerJugador = hayPrimerJugador;
    }

    public Jugador buscarJugador(String nombre) {
        for (iObserver observer : observers) {
            Jugador jugador = (Jugador) observer;
            if (jugador.getNombre().equalsIgnoreCase(nombre)) {
                return jugador;
            }
        }
        return null;
    }

    public boolean todosDeAcuerdo() {
        boolean respuesta = true;
        for (iObserver observer : observers) {
            Jugador jugador = (Jugador) observer;
            if (jugador.isSalidaMutua() == false) {
                respuesta = false;
            }
        }
        return respuesta;
    }

    public HashMap<Integer, String> getMensajes() {
        return mensajes;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    @Override
    public String toString() {
        return "Partida{" + "id=" + id + ", mensajes=" + mensajes +
                ", activa=" + activa + '}';
    }

}
