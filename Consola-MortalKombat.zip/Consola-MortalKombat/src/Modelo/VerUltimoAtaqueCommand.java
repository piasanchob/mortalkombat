package Modelo;

import Control.AdmPartidas;

public class VerUltimoAtaqueCommand implements ICommand {
    public static final String COMMAND_NAME = "VERULTIMOATAQUE";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String mensaje = args[1];
        AdmPartidas.getPartidas().get(1).notifyAllObservers("enviarMensaje", mensaje);
        System.out.println("Se ha enviado el mensaje del jugador "
                + atacante.getNombre() + "a todos los jugadores");
        return true;
    }
}