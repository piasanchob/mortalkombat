package Modelo;

import Control.AdmPartidas;

public class SalidaMutuaCommand implements ICommand {
    public static final String COMMAND_NAME = "SALIDAMUTUA";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        int sizeObservers = AdmPartidas.getPartidas().get(1).getObservers().size();
        int i = 0;
        while (i < sizeObservers) {
            Jugador jugadorSiguiente = (Jugador) AdmPartidas.getPartidas().get(1).getObservers().get(i);
            if (jugadorSiguiente.getNombre().equalsIgnoreCase(atacante.getNombre())) {
                jugadorSiguiente.setSalidaMutua(true);
                AdmPartidas.getPartidas().get(1).notifyAllObservers("enviarMensaje",
                        "El jugador " + atacante.getNombre() + " está a la espera de una salida mutua...");
                break;
            }
            i++;
        }
        if (AdmPartidas.getPartidas().get(1).todosDeAcuerdo() == true) {
            AdmPartidas.getPartidas().get(1).setActiva(false);
            AdmPartidas.getPartidas().get(1).notifyAllObservers("enviarMensaje",
                    "La partida ha sido terminada por mutuo acuerdo");
        }
        return true;
    }
}
