/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author gabri
 */
abstract public class Conexion {
    private final int PUERTO = 8080; // Puerto para la conexión
    private final String HOST = "localhost"; // Host para la conexión
    // protected ConfigurationManager conf;
    protected String mensaje; // Mensajes entrantes (recibidos) en el servidor
    protected ServerSocket socketServidor; // Socket del servidor
    protected Socket socketCliente; // Socket del cliente
    protected DataOutputStream salida; // Flujo de datos de salida

    public Conexion(String tipo) throws IOException { // Constructor
        if (tipo.equalsIgnoreCase("servidor")) {
            socketServidor = new ServerSocket(PUERTO);// Se crea el socket para el servidor en puerto 8080
        } else {
            socketCliente = new Socket(HOST, PUERTO); // Socket para el cliente en localhost en puerto 8080
        }
    }
}
