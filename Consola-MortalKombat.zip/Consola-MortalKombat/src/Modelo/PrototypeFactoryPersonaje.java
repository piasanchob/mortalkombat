package Modelo;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

public class PrototypeFactoryPersonaje{
    private static final HashMap<String, iPrototype> prototypes = rellenarPrototipos();
    
    public static HashMap<String, iPrototype> rellenarPrototipos(){
        try {
            HashMap<String, iPrototype> hashMap = new HashMap<>();
            List<Personaje> listaPersonajes = AdminJSON.extraerPersonajes();
            for (Personaje personaje : listaPersonajes) {
                hashMap.put(personaje.getNombre(), personaje);
            }
            return hashMap;
        } catch (IOException e) {
            return null;
        }
    }
    
    public static iPrototype getPrototype(String nombre){
        if(nombre != null && prototypes.containsKey(nombre)){
            return prototypes.get(nombre).deepClone();
        }
        return null;
    }
    
    public static void addPrototype(String nombre, iPrototype prototype){
        if(nombre != null && prototype != null && prototypes.containsKey(nombre)){
            prototypes.put(nombre, prototype);
        }
    }
}
