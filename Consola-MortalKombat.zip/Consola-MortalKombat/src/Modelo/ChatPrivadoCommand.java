package Modelo;

import Control.AdmPartidas;

/**
 *
 * @author gabri
 */
public class ChatPrivadoCommand implements ICommand {
    public static final String COMMAND_NAME = "CHATPRIVADO";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String jugadorDestino = args[1];
        String mensaje = args[2];
        Jugador destinatario = AdmPartidas.getPartidas().get(1).buscarJugador(jugadorDestino);
        if (destinatario != null) {
            destinatario.addMensajes(mensaje);
            atacante.addMensajes("Se ha enviado el mensaje del jugador "
                    + atacante.getNombre() + " con destino al jugador "
                    + destinatario.getNombre());
            System.out.println("Se ha enviado el mensaje del jugador "
                    + atacante.getNombre() + " con destino al jugador "
                    + destinatario.getNombre());
            return true;
        } else {
            atacante.addMensajes("El jugador no existe.");
            System.out.println("El jugador no existe.");
            return false;
        }
    }
}