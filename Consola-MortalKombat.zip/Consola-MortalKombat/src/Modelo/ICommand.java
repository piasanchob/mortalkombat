package Modelo;

public interface ICommand {
    public String getCommandName();

    public boolean execute(String[] args, Jugador atacante);
}
