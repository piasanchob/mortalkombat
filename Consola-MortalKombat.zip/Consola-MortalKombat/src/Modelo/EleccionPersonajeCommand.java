package Modelo;

import java.util.Arrays;

public class EleccionPersonajeCommand implements ICommand {
    public static final String COMMAND_NAME = "ELEGIRPERSONAJE";

    @Override
    public String getCommandName() {
        return COMMAND_NAME;
    }

    public boolean asignarPersonaje(Jugador atacante, String nombrePersonaje, String nombreArma1, String nombreArma2,
            String nombreArma3, String nombreArma4, String nombreArma5) {
        if (PrototypeFactoryPersonaje.getPrototype(nombrePersonaje) != null) {
            Personaje personajeAtacante = atacante.getEjercito().get(nombrePersonaje);
            if (personajeAtacante == null && atacante.getEjercito().size() < 4) {
                Arma arma = (Arma) PrototypeFactoryArma.getPrototype(nombreArma1);
                Arma arma2 = (Arma) PrototypeFactoryArma.getPrototype(nombreArma2);
                Arma arma3 = (Arma) PrototypeFactoryArma.getPrototype(nombreArma3);
                Arma arma4 = (Arma) PrototypeFactoryArma.getPrototype(nombreArma4);
                Arma arma5 = (Arma) PrototypeFactoryArma.getPrototype(nombreArma5);
                if (arma != null && arma2 != null && arma3 != null && arma4 != null && arma5 != null) {
                    atacante.addEjercito(nombrePersonaje);
                    personajeAtacante = atacante.getEjercito().get(nombrePersonaje);
                    personajeAtacante.agregarArma(nombreArma1);
                    personajeAtacante.agregarArma(nombreArma2);
                    personajeAtacante.agregarArma(nombreArma3);
                    personajeAtacante.agregarArma(nombreArma4);
                    personajeAtacante.agregarArma(nombreArma5);
                    personajeAtacante.setAparienciaActiva(personajeAtacante.getApariencias(0));
                    System.out.println(atacante.getEjercito());
                    return true;
                } else {
                    System.out.println("Error al asignar el arma al personaje del jugador");
                    return false;
                }
            } else {
                System.out.println("Jugador ya tiene este personaje en su ejercito");
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean execute(String[] args, Jugador atacante) {
        String nombrePersonaje = args[1];
        String nombreArma1 = args[2];
        String nombreArma2 = args[3];
        String nombreArma3 = args[4];
        String nombreArma4 = args[5];
        String nombreArma5 = args[6];
        boolean respuesta = asignarPersonaje(atacante,
                nombrePersonaje, nombreArma1,
                nombreArma2, nombreArma3,
                nombreArma4, nombreArma5);
        return respuesta;
    }
}
