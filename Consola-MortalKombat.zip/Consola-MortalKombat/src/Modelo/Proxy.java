package Modelo;

import java.io.IOException;
import java.time.LocalDateTime;

public class Proxy implements iLogger {
    private Logger Logger;

    public Proxy() {
        this.Logger = new Logger();
    }

    public String insertar(String texto, String nombre) {
        String commando = "";
        try {
            // Antes
            LocalDateTime fechaHora = LocalDateTime.now();
            String query = fechaHora + "El comando, los parametros y el resultado registrados son : " + texto;
            EscribirArchivo.registrarComandos(query, nombre);
            // Se delega el insert

            commando = Logger.insertar(texto, nombre);
            // Despues

        } catch (IOException e) {
            e.printStackTrace();
            commando = "";
        }
        return commando;
    }

    public Logger getLogger() {
        return Logger;
    }

    public void setLogger(Logger logger) {
        Logger = logger;
    }
}
