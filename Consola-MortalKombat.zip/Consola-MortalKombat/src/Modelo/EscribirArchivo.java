package Modelo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EscribirArchivo{
    
    public EscribirArchivo() {
    }

    public static void registrarComandos(String texto,String nombre) throws IOException{
        String ruta = System.getProperty("user.dir") + "/"+nombre+".txt";
        File file = new File(ruta);
            // Si el archivo no existe es creado
        if (!file.exists()) {
            file.createNewFile();
        }
        FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(texto +"\n");
        bw.close();
    }
/* 
    public static void registrarResultado(String json) throws IOException{
        String ruta = System.getProperty("user.dir") + "/c.txt";
        File file = new File(ruta);
            // Si el archivo no existe es creado
        if (!file.exists()) {
            file.createNewFile();
        }
        FileWriter fw = new FileWriter(file.getAbsoluteFile(),true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(json);
        bw.close();
    }
    */

}