package Modelo;

public class Tipo {
    private String nombre;
    private Tipo subtipo;

    public Tipo() {
    }

    public Tipo(String nombre) {
        this.nombre = nombre;
    }

    public Tipo getSubtipo() {
        return subtipo;
    }

    public void setSubtipo(Tipo subtipo) {
        this.subtipo = subtipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Tipo{" +
                "nombre='" + nombre + '\'' +
                ", subtipo=" + subtipo +
                '}';
    }
}
