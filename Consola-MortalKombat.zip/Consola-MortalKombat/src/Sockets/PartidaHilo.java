package Sockets;

import Control.AdmPartidas;
import Modelo.CommandManager;
import Modelo.Comodin;
import Modelo.ICommand;
import Modelo.Jugador;
import Modelo.Partida;
import Modelo.Personaje;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PartidaHilo extends Thread {
    private final CommandManager command;
    private Partida partida;
    private DataInputStream in;
    private DataOutputStream out;
    private String nickname;

    public PartidaHilo(DataInputStream in, DataOutputStream out) {
        this.in = in;
        this.out = out;
        this.command = CommandManager.getIntance();
        this.nickname = "";
    }

    public boolean verificarJugador(String nickname) {
        Jugador jugador = partida.buscarJugador(nickname);
        if (jugador == null) {
            partida.addObserver(jugador);
            System.out.println("El jugador " + nickname + " fue registrado");
            return true;
        }
        return false;
    }

    public void logIn() {
        try {
            String[] ary = new String[3];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            if (AdmPartidas.getPartidas().get(1).isHayPrimerJugador() == false) {
                ary[2] = "activar";
            } else {
                ary[2] = "activo";
            }
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, null);
            if (respuesta) {
                if (AdmPartidas.getPartidas().get(1).isHayPrimerJugador() == false) {
                    AdmPartidas.getPartidas().get(1).setHayPrimerJugador(true);
                }
                nickname = ary[1];
                Comodin comodin = new Comodin(AdmPartidas.getPartidas().get(1).buscarJugador(nickname));
                comodin.empezarTimer();
            }
            out.writeBoolean(respuesta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ELEGIRPERSONAJE -Joker -Gun -Submachine -SawHat -ShengBiao -IceAxe
    // ELEGIRPERSONAJE -Kunglao -Gun -Submachine -SawHat -ShengBiao -IceAxe
    // ELEGIRPERSONAJE -Robocop -Gun -Submachine -SawHat -ShengBiao -IceAxe
    // ELEGIRPERSONAJE -Rambo -Gun -Submachine -SawHat -ShengBiao -IceAxe
    // ATTACK -gabriel -Joker -Submachine
    // ATTACK -COMODIN -kevin -Robocop -Gun -Joker -Submachine
    // SELECT -gabriel
    public void eleccionPersonaje() {
        try {
            String[] ary = new String[7];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            ary[2] = in.readUTF();
            ary[3] = in.readUTF();
            ary[4] = in.readUTF();
            ary[5] = in.readUTF();
            ary[6] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(this.nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            if (respuesta) {
                out.writeUTF(atacante.getEjercito().get(ary[1]).getAparienciaActiva()); // Enviamos el string de la
                                                                                        // apariencia
                out.writeUTF(Arrays.toString(atacante.getEjercito().get(ary[1]).getArmas().get(ary[2]).getDanno()));
                out.writeUTF(Arrays.toString(atacante.getEjercito().get(ary[1]).getArmas().get(ary[3]).getDanno()));
                out.writeUTF(Arrays.toString(atacante.getEjercito().get(ary[1]).getArmas().get(ary[4]).getDanno()));
                out.writeUTF(Arrays.toString(atacante.getEjercito().get(ary[1]).getArmas().get(ary[5]).getDanno()));
                out.writeUTF(Arrays.toString(atacante.getEjercito().get(ary[1]).getArmas().get(ary[6]).getDanno()));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void atacar() {
        try {
            String[] ary = new String[4];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            ary[2] = in.readUTF();
            ary[3] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(this.nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            if (respuesta) {
                out.writeBoolean(respuesta);
                out.writeUTF(atacante.getEjercito().get(ary[2]).getTipo().getNombre());
                atacante = AdmPartidas.consultarPartida(1).buscarJugador(this.nickname);
                List<Personaje> personajes = new ArrayList<>(atacante.getEjercito().values());
                out.writeInt(personajes.get(0).getVida());
                out.writeInt(personajes.get(1).getVida());
                out.writeInt(personajes.get(2).getVida());
                out.writeInt(personajes.get(3).getVida());
                out.writeUTF(AdmPartidas.consultarPartida(1).buscarJugador(this.nickname).getMensajes()
                        .get(atacante.getMensajes().size() - 1));
            } else {
                out.writeBoolean(respuesta);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ATTACK -COMODIN -kevin -Robocop -Gun -Joker -Submachine
    public void atacarComodin() {
        try {
            String[] ary = new String[7];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            ary[2] = in.readUTF();
            ary[3] = in.readUTF();
            ary[4] = in.readUTF();
            ary[5] = in.readUTF();
            ary[6] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(this.nickname);
            ICommand co = command.getCommand(ary[1]);
            boolean respuesta = co.execute(ary, atacante);
            if (respuesta) {
                out.writeBoolean(respuesta);
                out.writeUTF(atacante.getEjercito().get(ary[3]).getTipo().getNombre());
                out.writeUTF(atacante.getEjercito().get(ary[5]).getTipo().getNombre());
                atacante = AdmPartidas.consultarPartida(1).buscarJugador(this.nickname);
                List<Personaje> personajes = new ArrayList<>(atacante.getEjercito().values());
                out.writeInt(personajes.get(0).getVida());
                out.writeInt(personajes.get(1).getVida());
                out.writeInt(personajes.get(2).getVida());
                out.writeInt(personajes.get(3).getVida());
                out.writeUTF(AdmPartidas.consultarPartida(1).buscarJugador(this.nickname).getMensajes()
                        .get(atacante.getMensajes().size() - 1));
            } else {
                out.writeBoolean(respuesta);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void chatPublico() {
        try {
            String[] ary = new String[2];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void verMensajes() {
        try {
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            if (atacante.getMensajes().isEmpty()) {
                out.writeUTF("No existen mensajes disponibles" + "\n");
            } else {
                String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
                out.writeUTF(mensaje + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void chatPrivado() {
        try {
            String[] ary = new String[3];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            ary[2] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void recargar() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void salidaMutua() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            out.writeUTF(atacante.getNombre());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void rendirse() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            out.writeUTF(atacante.getNombre());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void pasarTurno() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void verArchivo() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            if (atacante.getMensajes().isEmpty()) {
                out.writeUTF("No existen mensajes disponibles" + "\n");
            } else {
                String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
                out.writeUTF(mensaje + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void selectJugador() {
        try {
            String[] ary = new String[2];
            ary[0] = in.readUTF();
            ary[1] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
            out.writeUTF(mensaje + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void MyStatus() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
            out.writeUTF(mensaje + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void Ranking() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            ICommand co = command.getCommand(ary[0]);
            boolean respuesta = co.execute(ary, atacante);
            out.writeBoolean(respuesta);
            atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
            out.writeUTF(mensaje + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void UltimoAtaque() {
        try {
            String[] ary = new String[1];
            ary[0] = in.readUTF();
            Jugador atacante = AdmPartidas.consultarPartida(1).buscarJugador(nickname);
            String mensaje = atacante.getMensajes().get(atacante.getMensajes().size() - 1);
            out.writeUTF(mensaje + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void menuInicio() {
        try {
            boolean salir = false;
            int opcion = 0;
            while (!salir) {
                opcion = in.readInt();
                switch (opcion) {
                    case 1 -> logIn();
                    case 7 -> verMensajes();
                    case 12 -> verArchivo();
                    case 13 -> selectJugador();
                    case 14 -> MyStatus();
                    case 15 -> Ranking();
                    case 16 -> UltimoAtaque();
                    default -> {
                        if (AdmPartidas.getPartidas().get(1).buscarJugador(nickname).isTurno()) {
                            out.writeBoolean(true);
                            switch (opcion) {
                                case 2 -> eleccionPersonaje();
                                case 3 -> atacar();
                                case 4 -> atacarComodin();
                                case 5 -> chatPublico();
                                case 6 -> chatPrivado();
                                case 8 -> recargar();
                                case 9 -> salidaMutua();
                                case 10 -> rendirse();
                                case 11 -> pasarTurno();
                                default -> {
                                }
                            }
                        } else {
                            out.writeBoolean(false);
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        menuInicio();
    }
}