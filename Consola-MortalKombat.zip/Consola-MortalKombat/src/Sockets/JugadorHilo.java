package Sockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import Vista.Juego;
public class JugadorHilo extends Thread{
    private DataInputStream in;
    private DataOutputStream out;
    private ObjectOutputStream objSender;
    public JugadorHilo(DataInputStream in, DataOutputStream out) {
        this.in = in;
        this.out = out;
    }
    
    @Override
    public void run() {
        Juego juego = new Juego(in, out);
        juego.setVisible(true);
    }
}