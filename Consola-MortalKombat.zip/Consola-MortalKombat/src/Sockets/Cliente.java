/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sockets;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 *
 * @author diego
 */
public class Cliente {
    Socket socket;

    public Cliente() {
        conectar();
    }

    public void conectar() {
        try {
            socket = new Socket("localhost", 8084);// 192.4.1.1 o "127.0.0.1" o "localhost"
            System.out.println("Soy el cliente y me conecté");
            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            JugadorHilo jugadorHilo = new JugadorHilo(entrada, salida);
            jugadorHilo.start();
            jugadorHilo.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
