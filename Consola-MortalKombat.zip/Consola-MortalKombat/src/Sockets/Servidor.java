/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sockets;

import Control.AdmPartidas;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import Modelo.Partida;

/**
 *
 * @author diego
 */
public class Servidor {
    public Servidor() {
        start();
    }

    public void start() {
        try {
            Socket socket;
            try (ServerSocket server = new ServerSocket(8084)) {
                System.out.println("Servidor iniciado");
                while (true) {
                    socket = server.accept();
                    System.out.println("Soy el cliente y me conecté");
                    DataInputStream in = new DataInputStream(socket.getInputStream());
                    DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                    Partida partida = new Partida(1);
                    AdmPartidas.agregarPartida(partida);
                    PartidaHilo hilo = new PartidaHilo(in, out);
                    hilo.start();
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
